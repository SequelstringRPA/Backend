from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation



def times_internet():
	##---------------fixed_functions_For_excel-----------##

	po_number,state_code = create_workbook()
    ##----------------------------------------##
	def pdf_extraction(data2):
		print(data2)
		global input_data
		header_values = header_fields(data2)
		#print(header_values)
		invoice = header_values[0]
		date = header_values[1]
		gst = header_values[2]
		pan = header_values[3]
		tax = header_values[4]
		total = header_values[5]

		text = header_values[6]
		text1 = header_values[8]
		text2 = text1.replace('\n',' ')
		# print(text2)
		# print(text)

		try:
			vendor_name = re.search(r'(?i)TIMES INTERNET.*?(Limited|Ltd)',text).group()
		except:
			vendor_name = 'NA'

		try:
			try:
				address = re.search(r'(?s)Regd. Office.*?\d{6}',text).group().replace('Regd. Office',' ').replace('\n','').replace(':',' ').strip()
			except:
				address = re.search(r'(?i)Address.*?\d{6}',text2).group()
		except:
			address = 'NA'

		try:
			total1 = re.search(r'Total Gross Amount.*?\d+\S+\d+',text).group().replace(' ','')
			total = re.search(r'\d+\S+\d+',total1).group().strip()
		except:
			total = total

		try:
			line_item_list = re.search(r'(?si)Description.*?Total Invoice Value',text).group()
			# print(line_item_list) 
			tax_list = []
			item_list = re.findall(r'[A-Za-z].*[A-Za-z].*?\.\d{2}.*\.\d{2}',line_item_list)
			for taxes in item_list:
				taxes = taxes.split()[-2].replace(',','').strip()
				tax_list.append(float(taxes))
			# print(tax_list)
			tax = sum(tax_list)
			# print(tax)

			line_items = re.findall(r'[A-Za-z].*[A-Za-z].*?\.\d+\S+',line_item_list)
			for line_item in line_items:
				line_item = line_item.replace(',','')
				# print(line_item)
				line_item = line_item.strip().rsplit(' ',3)
				des = line_item[0]
				basic = line_item[-1]
				qty = line_item[-3]


				input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
				# print(input_data)
				print('\n')
				vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
				print(vl)
				vl1 = list(vl.values())
		       
				list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
				print("list1" , list1)
				# create_excel(list1)

				if vl1.count(True) == 3:
					print('Validation Successful')
					create_excel(list1)
					print('Invoice data extracted to excel')
				else:
				    print('Exception Occured')
		except:
			
			line_item_list = re.search(r'(?si)Description.*?Total\s+Amount',text).group()
			# print(line_item_list)
			line_items = re.findall(r'[A-Za-z].*[A-Za-z].*?\.\d{2}',line_item_list)

			for line_item in line_items:
				line_item = line_item.replace(',','')
				# print(line_item)
				try:
					item1 = re.search(r'\d+\S+\s+count.*?\.\d{2}',line_item).group()
					item = item1.split('counts')
					# print(item)
					qty = item[0].strip()
					basic = re.search(r'\d.*',item[1]).group().strip()
					des = line_item.replace(item1,'')
				except:
					line_item = line_item.strip().rsplit(' ',2)
					# print(line_item)
					des = line_item[0]
					qty = line_item[1]
					basic = line_item[2]

				input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
				# print(input_data)
				print('\n')
				vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
				print(vl)
				vl1 = list(vl.values())
		       
				list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
				print("list1" , list1)
				# create_excel(list1)

				if vl1.count(True) == 3:
					print('Validation Successful')
					create_excel(list1)
					print('Invoice data extracted to excel')
				else:
				    print('Exception Occured')
		


			# print(vendor_name)
			# print(address)
			# print('Invoice No:',invoice)
			# print('Invoice Date:',date)
			# print('GST No:',gst)
			# print('PAN No:',pan)
			# print('Tax',tax)
			# print('Total Amount:',total)
			# print('Description:',des)
			# print('Basic Amount:',basic)
			# print('Quantity:',qty)

			


	path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
	for data in os.listdir(path):
		data2 = (path+'\\%s')%data
		if data2.endswith('.pdf'):
			pdf_extraction(data2)
		


times_internet()