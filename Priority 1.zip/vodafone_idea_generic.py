from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation


def vodafone_idea():
	##---------------fixed_functions_For_excel-----------##

	po_number,state_code = create_workbook()
    ##----------------------------------------##
	def pdf_extraction(data2):
		print(data2)
		global input_data
		header_values = header_fields(data2)
		#print(header_values)
		invoice = header_values[0]
		date = header_values[1]
		gst = header_values[2]
		pan = header_values[3]
		tax = header_values[4]
		total = header_values[5]

		text = header_values[6]
		# print(text)

		try:
			vendor_name = re.search(r'(?i)Vodafone.*?(Limited|Ltd)',text).group()
		except:
			vendor_name = 'NA'
		

		try: 
			address = re.search(r'(?s)Regd Office.*?\d{6}',text).group().replace('Regd Office','').replace('Address','').replace(':','').strip()
		except:
			address = 'NA'
		

		try:
			if re.search(r'(?s)Total taxable charges.*?\d+\S\d+.*?Tax.*?\d+\S\d+',text):
				tax = re.search(r'(?s)Total taxable charges.*?\d+\S\d+.*?Tax.*?\d+\S\d+',text).group().rsplit('Tax',1)[-1]
				tax = re.search(r'\d+\S\d+',tax).group().strip()
		except:
			tax = 'NA'

		try:
			total = re.search(r'(TOTAL PAYABLE|Total Charges Including Tax).*?\d+\S\d+',text).group()
			total = re.search(r'\d+\S\d+',total).group().strip()
		except:
			total = 'NA'

		qty = 1
		des = ''

		try:
			if re.search(r'Total taxable charges.*?\d+\S\d+',text):
				basic = re.search(r'Total taxable charges.*?\d+\S\d+',text).group()
				basic = re.search(r'\d+\S+\d+',basic).group()
			else:
				basic = re.search(r'Total Charges Excluding Tax.*\d+\S\d+',text).group()
				basic = re.findall(r'\d+\S+\d+',basic)[-1]
		except:
			basic = 'NA'


		print('Vendor Name:',vendor_name)
		print('Address:',address)
		print('Invoice No:',invoice)
		print('Inoice Date:',date)
		print('GST No:',gst)
		print('PAN No:',pan)
		print('Tax',tax)
		print('Total Amount:',total)
		print('Description:',des)
		print('Basic Amount:',basic)
		print('Quantity:',qty)

		# if float(str(tax).replace(',','')) + float(str(basic).replace(',','')) == float(str(total).replace(',','')):
		# 	print('CORRECT')


		input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
		# print(input_data)
		print('\n')
		vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
		print(vl)
		vl1 = list(vl.values())
       
		list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
		print("list1" , list1)
		# create_excel(list1)

		if vl1.count(True) == 3:
			print('Validation Successful')
			create_excel(list1)
			print('Invoice data extracted to excel')
		else:
		    print('Exception Occured')


	path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
	for data in os.listdir(path):
		data2 = (path+'\\%s')%data
		if data2.endswith('.pdf'):
			pdf_extraction(data2)
		


vodafone_idea()