from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation


def buisness_think():

    po_number,state_code = create_workbook()
    ##----------------------------------------##



    def extract_pdf_df_tabula(pdf_path):
        df = tabula.read_pdf(pdf_path, pages='all')[0]
        return df

    def plumber(file):
        with pdfplumber.open(file)as pdf:
            page = pdf.pages
            text=''
            for i ,pg in enumerate(page):
                text1=page[i].extract_text()
                text1=text1.replace('\n',' ')
                text=text+text1

            return text          # printing text

    def get_index(df, string):
        for i in range(0, df.shape[1]):
            for j in range(0, df.shape[0]):
                # print(type(df._get_value(j, i, takeable = True)))
                strg = str(df._get_value(j, i, takeable = True))   
                if string in strg:
                    return j, i
                    break

    def get_description(df, start, split):
        DESCRIPTION_List  = []
        vals_list = []
        flg = 0
        i_copy = 0
        for i in range(start, df.shape[0]-1):
            if pd.isnull(df._get_value(i, 0, takeable = True)):
                DESCRIPTION_List.append(DESCRIPTION[2:])
                i_copy = i
                break
            if pd.notnull(df._get_value(i, 1, takeable = True)) and len(df._get_value(i, 1, takeable = True).split()) == split:
                vals = df._get_value(i, 1, takeable = True).split()
                vals_list.append(vals)
                if flg == 1:
                    DESCRIPTION_List.append(DESCRIPTION[2:])
                DESCRIPTION = ""
                DESCRIPTION =  DESCRIPTION + df._get_value(i, 0, takeable = True)
                flg = 1
            if pd.isnull(df._get_value(i, 1, takeable = True)):
                DESCRIPTION = DESCRIPTION + " " + df._get_value(i, 0, takeable = True)
        return DESCRIPTION_List, vals_list


    def plumber_table(file):
        resource_manager = PDFResourceManager()
        ff_handle = io.StringIO()
        converter = TextConverter(resource_manager, ff_handle)
        page_interpreter = PDFPageInterpreter(resource_manager, converter)
        with open (file, 'rb') as fh:
            for page in PDFPage.get_pages(fh,
                                          caching=True,
                                          check_extractable=True):
                page_interpreter.process_page(page)
            text_miner = ff_handle.getvalue()
        converter.close()
        # print(text_miner)

        with pdfplumber.open(file) as pdf:
            pages = pdf.pages
            text = ''
            text_t = []
            for i in range(0,len(pages)):
                page = pages[i]
                text1 = page.extract_text(x_tolerance=3, y_tolerance=3)
                if text1 != None:
                    text = text + text1
                table = page.extract_tables(table_settings = {"text_tolerance": 3,"keep_blank_chars": False})
                text_t = text_t + table
        # print (text)
        # print(text_t)
        print('\n')
        return text, text_t         # printing text



    def extraction_process(file):
        global VENDOR, ADDRESS,TAX_AMOUNT, INVOICE_NUM, GSTIN_NO, INVOICE_DATE, DESCRIPTION, QUANTITY, BASIC_AMOUNT, TOTAL_AMOUNT, PAN, input_data

        text = plumber(file)

        header_values = header_fields(file)
        invoice = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]

        VENDOR =  "BusinessThink Learning Solutions"
        ADDRESS = "1001 Tower 4, South Close Nirvana Country, Sector, 50 Gurgaon, Haryana - 122018,  INDIA : Phone: 9871095285"
        INVOICE_NUM = re.search("Invoice.*?\d+", text).group().split()[-1]
        INVOICE_DATE = date
        GSTIN_NO = gst
        PAN = pan

        TAX_AMOUNT = tax
        TOTAL_AMOUNT = total

        DESCRIPTION_string = re.search("Amount \(INR\).*?IGST", text).group().replace("Amount (INR)", "")
        DESCRIPTION = re.search("(([A-Za-z]+\s+)+) Per.*?\d+ \d+,?\d+ \d+?,?\d+,?\d+.\d+ (([A-Za-z]+\s+)+)", DESCRIPTION_string).group(1) + " " + re.search("(([A-Za-z]+\s+)+) Per.*?\d+ \d+,?\d+ \d+?,?\d+,?\d+.\d+ (([A-Za-z]+\s+)+)", DESCRIPTION_string).group(3)
        BASIC_AMOUNT = re.search("(([A-Za-z]+\s+)+) Per.*?(\d+) (\d+,?\d+) \d+?,?\d+,?\d+.\d+ (([A-Za-z]+\s+)+)", DESCRIPTION_string).group(4)
        QUANTITY = re.search("(([A-Za-z]+\s+)+) Per.*?(\d+) (\d+,?\d+) \d+?,?\d+,?\d+.\d+ (([A-Za-z]+\s+)+)", DESCRIPTION_string).group(3)
        
        




        
        # print(VENDOR,po_number,ADDRESS,state_code,TAX_AMOUNT,INVOICE_NUM,GSTIN_NO,INVOICE_DATE,DESCRIPTION,QUANTITY,BASIC_AMOUNT,TOTAL_AMOUNT,PAN)

            
        # print('\n')
        # vl = validation.valid_data(input_data)# function call
        # print(vl)
        # vl1 = list(vl.values())

        input_data = []

        # for i in range(len(DESCRIPTION_List)):
            # input_data.append([VENDOR, po_number, ADDRESS, state_code, TAX_AMOUNT, INVOICE_NUM, GSTIN_NO, INVOICE_DATE,DESCRIPTION_List[i], vals_list[i][0], vals_list[i][1], TOTAL_AMOUNT, PAN])
        # print(input_data)
        input_data = [[VENDOR,po_number,ADDRESS,state_code,TAX_AMOUNT,INVOICE_NUM,GSTIN_NO,INVOICE_DATE,DESCRIPTION,QUANTITY,BASIC_AMOUNT,TOTAL_AMOUNT,PAN]]
        # if vl1.count(True) == 3:
        create_excel(input_data)
        # else:
        # print('Exception Occured')

    output_folder = r"C:\Users\AbhigyanSS\Desktop\proj\Solutions and Insights\Invoices and Do"
    ##-------------------------Proccess_Intial--------------------------##
    path = os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
    for file1 in os.listdir(path):
        file=(path+'\%s')%file1
        if file.endswith('.pdf'):
            print(file)
            extraction_process(file)

buisness_think()
