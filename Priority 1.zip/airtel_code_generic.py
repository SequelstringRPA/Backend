from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation


def bharti_airtel():
	##---------------fixed_functions_For_excel-----------##

	po_number,state_code = create_workbook()
    ##----------------------------------------##
	def pdf_extraction(data2):
		print(data2)
		global input_data
		header_values = header_fields(data2)
		#print(header_values)
		invoice = header_values[0]
		date = header_values[1]
		gst = header_values[2]
		pan = header_values[3]
		tax = header_values[4]
		total = header_values[5]

		text = header_values[6]
		# print(text)

		try:
			vendor_name = re.search(r'(?i)Bharti.*?(Limited|Ltd)',text).group()
		except:
			vendor_name = 'NA'

		try:
			if re.search(r'(?s)Regd Office.*?\d{6}',text):
				address = re.search(r'(?s)Regd Office.*?\d{6}',text).group().replace('Regd Office','').replace(':','').strip()
			else:
				address = re.search(r'(?s)Limited.*?\s\d{6}\s',text).group().replace('  ','').replace('Limited','').replace('\n',' ').strip()
		except:
			address = 'NA'


		if gst == 'NA':
			gst = re.search(r'Airtel GST.*?[A-Z0-9]{15}',text).group()
			gst = re.search(r'[A-Z0-9]{15}',text).group()
		if pan == 'NA':
			pan = gst[2:12]
		if total == 'NA':
			total = re.search(r'CHARGES.*?\d+\,\S+\d+|\d+\S\d+\.\d{2}|\d+\S\d+\.\d{1}',text).group().replace('CHARGES','').replace(' ','').strip()

		qty = 1
		des = ''

		try:
			if re.search(r'Sub-Total.*?\d+\S+\d+',text):
				basic = re.search(r'Sub-Total.*?\d+\S+\d+',text).group()
				basic = re.search(r'\d+\S+\d+',basic).group()
			else:
				basic1 = re.search(r'[^a-z][A-Z]+.*?INR.*?\d+\S+\d+',text).group()
				basic = basic1.split('INR')[-1].strip()
				des = basic1.split('INR')[0].split('  ',1)[1].replace('  ','')
		except:
			basic = 'NA'
			print('Basic',basic)

		if total == 'NA':
			print('Total',total)

		print(address)
		print('Invoice No:',invoice)
		print('Inoice Date:',date)
		print('GST No:',gst)
		print('PAN No:',pan)
		print('Tax',tax)
		print('Total Amount:',total)
		print('Description:',des)
		print('Basic Amount:',basic)
		print('Quantity:',qty)

		input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
		# print(input_data)
		print('\n')
		vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
		print(vl)
		vl1 = list(vl.values())
       
		list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
		# print("list1" , list1)
		# create_excel(list1)

		if vl1.count(True) == 3:
			print('Validation Successful')
			create_excel(list1)
			print('Invoice data extracted to excel')
		else:
		    print('Exception Occured')


	path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
	for data in os.listdir(path):
		data2 = (path+'\\%s')%data
		if data2.endswith('.pdf'):
			pdf_extraction(data2)
		


bharti_airtel()