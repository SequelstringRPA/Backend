from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation

def vir_softech():

    ##---------------fixed_functions_For_excel-----------##

    po_number,state_code = create_workbook()

    def pdf_extraction(file):
        global input_data

        header_values = header_fields(file)
        invoice = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]
        text = header_values[6]
        text1 = header_values[8]
        text2 = text1.replace('\n',' ')

        try:
            vendor_name = re.search(r'(?i)VIR.*?(Limited|Ltd)',text).group()
        except:
            vendor_name = 'NA'

        try:
            address = re.search(f'(?s){vendor_name}.*?\d{{6}}',text2).group().replace('\n','').replace('  ',' ').strip()
        except:
            address = 'NA'

        total = re.search("Total \(Rounded off\).*?\d+", text).group().split()[-1].strip()

        line_item_list = re.search(r'(?si)Description.*?(IGST|SGST|CGST)',text).group()
        # print(line_item_list)
        line_items = re.findall(r'\d+.*?[A-Za-z].*[A-Za-z].*\.\d{2}',line_item_list)
        for line_item in line_items:
            # print(line_item)
            des = re.search(r'[A-Za-z].*[A-Za-z]',line_item).group()
            line_item = line_item.rsplit(' ',3)
            # print(line_item)
            qty = line_item[-2]
            basic = line_item[-3]

            print(vendor_name)
            print(address)
            print('Invoice No:',invoice)
            print('Invoice Date:',date)
            print('GST No:',gst)
            print('PAN No:',pan)
            print('Tax',tax)
            print('Total Amount:',total)
            print('Description:',des)
            print('Basic Amount:',basic)
            print('Quantity:',qty)

            input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
            # print(input_data)
            print('\n')
            vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
            print(vl)
            vl1 = list(vl.values())
           
            list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
            print("list1" , list1)
            # create_excel(list1)

            if vl1.count(True) == 3:
                print('Validation Successful')
                create_excel(list1)
                print('Invoice data extracted to excel')
            else:
                print('Exception Occured')

    ##-------------------------Proccess_Intial--------------------------##
    path = os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
    for file1 in os.listdir(path):
        file=(path+'\%s')%file1
        if file.endswith('.pdf'):
            print(file)
            pdf_extraction(file)

vir_softech()
