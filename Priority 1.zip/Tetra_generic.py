from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation

def Tetra():

    po_number,state_code = create_workbook()
    ##----------------------------------------##


    def pdf_extraction(data2):

        print(data2)
        global input_data
        header_values = header_fields(data2)

        invoice = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]
        text = header_values[6]
        text_t = header_values[7]
        # print(text)
        # print(re.sub("\n", " ",text))



        vendor_name =  "Tetra Information Services Pvt. Ltd"
        address = "252-H, 1St Floor, Kailash Plaza,Sant Nagar, East of Kailash New Delhi-110065"
        invoice = re.search("\w\/.*",invoice).group()
        
        pan = gst[2:12]

        total = re.search("Grand Total.*?\d+",text).group().split()[-1]
        
        Description_list = re.findall(r"^\s+\d\d?\s+\d{7}.*?\n", text, flags=re.MULTILINE)
        if len(Description_list) == 0:
            Description_list = re.findall(r"^\d\d?\.?\s.*?\n", text, flags=re.MULTILINE)
            for i in range(len(Description_list)):
                    regexexp = re.compile("\d+\s+18\%\s+\d+")
                    if regexexp.search(Description_list[i]):
                        des = re.search("\w+.*?\d", Description_list[i]).group().split()
                        del des[0]
                        del des[-1]
                        des = " ".join(des)
                        qty = Description_list[i].split()[-3]
                        basic = Description_list[i].split()[-2]

                        input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
                        print(input_data)
                        print('\n')
                        list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
                        create_excel(list1)
  
        else:
            for i in range(len(Description_list)):
                des = Description_list[i].split()
                del des[0:2]
                del des[-4:-1]
                del des[-1]
                des = " ".join(des)
                qty = Description_list[i].split()[-4]
                basic = Description_list[i].split()[-2]
                
                input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
                print(input_data)
                print('\n')
                list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
                create_excel(list1)
        


        
        

        # print(address)
        # print('Invoice No:',invoice)
        # print('Inoice Date:',date)
        # print('GST No:',gst)
        # print('PAN No:',pan)
        # print('Tax',tax)
        # print('Total Amount:',total)
        # print('Description:',des)
        # print('Basic Amount:',basic)
        # print('Quantity:',qty)

        # print(mylist)
            # input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
            # print(input_data)
            # print('\n')
        # vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
        # print(vl)
        # vl1 = list(vl.values())
       
            # list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
        # print("list1" , list1)
            # create_excel(list1)

        # if vl1.count(True) == 3:
        #     print('Validation Successful')
        #     create_excel(list1)
        #     print('Invoice data extracted to excel')
        # else:
        #     print('Exception Occured')

        ##-------------------------Proccess_Intial--------------------------##
    path = os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
    for data in os.listdir(path):
        data2 = (path+'\\%s')%data
        if data2.endswith('.pdf'):
            pdf_extraction(data2)

Tetra()
