from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation



def format_type_one():
##---------------fixed_functions_For_excel-----------##

	po_number,state_code = create_workbook()

	
	def pdf_extraction(data2):
		print('\n')
		global invoice,date,gst,pan,tax,total,des,qty,basic
		header_values = header_fields(data2)
		#print(header_values)
		date = header_values[1]
		gst = header_values[2]
		pan = header_values[3]
		print(data2)

		text = header_values[6]
		t_text = header_values[7]

		print('\n')

		vendor_details = t_text[0][0]

		vendor_details = ['None' if v is None else v for v in vendor_details]
		# print(vendor_details)
		################################# Vendor Name #######################################

		if re.search(r'(?i)Business Octane.*?(Ltd.|Ltd|Limited)',text):
			vendor_name1 = re.search(r'(?i)Business Octane.*?(Ltd.|Ltd|Limited)',text).group().strip()
		elif re.search(r'(?i)QualityKiosk.*?(Ltd.|Ltd|Limited)',text):
			vendor_name1 = re.search(r'(?i)QualityKiosk.*?(Ltd.|Ltd|Limited)',text).group().strip()
		elif re.search(r'(?i)Bits & Bytes.*?(Ltd.|Ltd|Limited)',text):
			vendor_name1 = re.search(r'(?i)Bits & Bytes.*?(Ltd.|Ltd|Limited)',text).group().strip()
		elif re.search(r'(?i)Acpl.*?(Ltd.|Ltd|Limited)',text):
			vendor_name1 = re.search(r'(?i)Acpl.*?(Ltd.|Ltd|Limited)',text).group().strip()
		elif re.search(r'(?i)EIM Solutions.*?(Ltd.|Ltd|Limited)',text):
			vendor_name1 = re.search(r'(?i)EIM Solutions.*?(Ltd.|Ltd|Limited)',text).group().strip()
		elif re.search(r'(?i)KPOINT.*?(Ltd.|Ltd|Limited)',text):
			vendor_name1 = re.search(r'(?i)KPOINT.*?(Ltd.|Ltd|Limited)',text).group().strip()
		elif re.search(r'(?i)Neilsoft.*?(Ltd.|Ltd|Limited)',text):
			vendor_name1 = re.search(r'(?i)Neilsoft.*?(Ltd.|Ltd|Limited)',text).group().strip()
		elif re.search(r'(?i)Presentation People',text):
			vendor_name1 = re.search(r'(?i)Presentation People',text).group().strip()
		elif re.search(r'(?i)Indusface.*?(Ltd.|Ltd|Limited)',text):
			vendor_name1 = re.search(r'(?i)Indusface.*?(Ltd.|Ltd|Limited)',text).group().strip()
		elif re.search(r'(?i)EMBEDDED SYSTEMS.*?(Ltd.|Ltd|Limited)',text):
			vendor_name1 = re.search(r'(?i)EMBEDDED SYSTEMS.*?(Ltd.|Ltd|Limited)',text).group().strip()
		elif re.search(r'(?i)MicroGenesis.*?(Ltd.|Ltd|Limited)',text):
			vendor_name1 = re.search(r'(?i)MicroGenesis.*?(Ltd.|Ltd|Limited)',text).group().strip()

		# print(vendor_name1)

		if vendor_name1 in vendor_details[0].split('\n',1)[0]:
			vendor_name = vendor_name1

		print('Vendor Name:',vendor_name)

		#################################### Address ############################################

		try:
			address = re.search(f'(?s){vendor_name}.*?(GST|PAN)',vendor_details[0]).group().replace('GST','').replace('PAN','').replace(vendor_name,'').replace('\n',' ').strip()
		except:
			address = 'NA'
		print('Vendor Address:',address)

		################################## Invoice Number ######################################

		for values in vendor_details:
			if 'Invoice'.casefold() in values.casefold():
				# print(values)
				try:
					invoice = re.search(r'(\d|[A-Z]).*?[0-9A-Z\/\-]+\d{2,16}',values).group()
				except:
					invoice = 'NA'

		print('Invoice No:',invoice)

		################################### Invoice Date ######################################

		print('Invoice Date:',date)

		################################# GST No. #############################################
		print('GST No.',gst)

		################################# PAN No. #############################################
		if pan == 'NA':
			pan = gst[2:12]
		print('PAN No:',pan)


		################################ Total Amount #########################################

		total_amount = re.search(r'(?s)Total.*?Amount Chargeable',text).group()
		total_list = re.findall(r'\d+\S+\d{2}',total_amount)
		# print(total_list)
		total = total_list[-1]
		print('Total Amount:',total)

		################################ Total Tax ############################################

		tax_amount1 = re.search(r'((IGST.*?INR|IGST.*?%|IGST)|(SGST.*?%|SGST|Sgst)|(CGST.*%|CGST|Cgst)).*?(\d\S\d+\.\d{2}|\d+\S+\d+)',text)
		tax_amount = tax_amount1.group()
		# print(tax_amount)
		if 'SGST'.casefold() in tax_amount.casefold() or 'CGST'.casefold() in tax_amount.casefold():
			tax1 = tax_amount1.group(5).replace(',','')
			tax = float(tax1)*2
		elif 'IGST'.casefold() in tax_amount.casefold():
			tax = tax_amount1.group(5)
		print('Tax Amount:',tax)

		############################### Line Items ############################################

		line_item_values = re.search(r'(?s)(Description|Particulars).*?(IGST|SGST|CGST|Sgst|Cgst)',text).group()
		if re.search(r'\d+\.\d+\.\d{2,4}',line_item_values):
			extra = re.search(r'\d+\.\d+\.\d{2,4}',line_item_values).group()
			line_item_values = line_item_values.replace(extra,'')
		# print(line_item_values)

		line_items = re.findall(r'([A-Z][A-Za-z0-9].*(\d{4,6}|\s{4,8}).*\d+((\S+\.)|\.)\d{2})',line_item_values)
		# print(line_items)	
		for line_item in line_items:
			line_item = line_item[0].replace('(','').replace(')','').replace('18 %','').replace('18%','').replace('9%','').replace('9 %','').replace('+','').strip()
			# print(line_item)

			try:
				des = re.search(r'[A-Za-z].*\d{4,6} ',line_item).group()
			except:
				des = line_item.split('    ')[0].strip()

			regex = re.search(des,line_item).group()
			line_item = line_item.replace(regex,'').strip()
			line_item1 = line_item.split()
			# print(line_item)
			if len(line_item1) == 1 and re.search(r'\d+\S+\d',line_item1[0]):
				basic = line_item1[0]
				qty = 1

			else:
				# print(line_item)
				data = re.findall(r'\d+.*?[A-Za-z]+',line_item)
				# print(data)
				qty = re.search(r'\d+\S+\d|\d+',data[0]).group().strip()
				basic = re.search(r'\d+\S+\d',data[1]).group().strip()
			# print('Description:',des)
			# print('Basic Amount:',basic)
			# print('Quantity:',qty)

			# print(mylist)
			input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
			# print(input_data)
			print('\n')
			vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
			# print(vl)
			vl1 = list(vl.values())
           
			list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
			print("list1" , list1)
			# create_excel(list1)

			if vl1.count(True) == 3:
				print('Validation Successful')
				create_excel(list1)
				print('Invoice data extracted to excel')
			else:
				print('Exception Occured')




	path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
	for data in os.listdir(path):
		data2 = (path+'\\%s')%data
		if data2.endswith('.pdf'):
			pdf_extraction(data2)

format_type_one()