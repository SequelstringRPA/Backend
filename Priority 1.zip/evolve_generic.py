from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation


def evolve_brands():
	##---------------fixed_functions_For_excel-----------##

	po_number,state_code = create_workbook()
    ##----------------------------------------##
	def pdf_extraction(data2):
		print(data2)
		global input_data
		header_values = header_fields(data2)
		#print(header_values)
		invoice = header_values[0]
		date = header_values[1]
		gst = header_values[2]
		pan = header_values[3]
		tax = header_values[4]
		total = header_values[5]

		text = header_values[6]
		# print(text)

		try:
			vendor_name = re.search(r'(?i)Evolve.*?(Limited|Ltd)',text).group()
		except:
			vendor_name = 'NA'

		try:
			address = re.search(r'(?s)[A-Z]+.*?\d{6}',text).group().replace('\n',' ').strip()
			if len(address) > 100:
				address = re.search(r'(?s)Page.*?\s\d\sof\s\d.*?\d{6}',text).group().replace('\n',' ').strip()
		except:
			address = 'NA'

		invoice = re.search(r'Invoice No.*?(([A-Z0-9\\\/\-^s]\d\S+){2,16})',text).group().split('No')[-1].strip()

		date = re.search(r'Date.*?(\d+\s+[A-Za-z]+\s+\d+|\d+\/[A-Za-z]+\/\d+|\d+\.[A-Za-z]+\.\d+|\d+\-[A-Za-z]+\-\d+|\d+\s+\d+\s+\d+|\d+\/\d+\/\d+|\d+\.\d+\.\d+|\d+\-\d+\-\d+|\d{1,2}(st|nd|rd|th)\s+[A-Za-z]+\s\d{2,4})',text).group()
		date = re.search(r'\d+\s+[A-Za-z]+\s+\d+|\d+\/[A-Za-z]+\/\d+|\d+\.[A-Za-z]+\.\d+|\d+\-[A-Za-z]+\-\d+|\d+\s+\d+\s+\d+|\d+\/\d+\/\d+|\d+\.\d+\.\d+|\d+\-\d+\-\d+|\d{1,2}(st|nd|rd|th)\s+[A-Za-z]+\s\d{2,4}',date).group()

		tax_list = re.findall(r'((CGST|SGST|IGST).*\d\.\d{2})',text)
		tax = 0
		for tx in tax_list:
			tx = re.findall(r'\d+\S+\d+',tx[0])[-1].strip().replace(',','')
			tax = float(tax) + float(tx)

		line_item_list = re.search(r'(?s)Particulars.*?Sub Total',text).group()
		# print(line_item_list)
		line_items = re.findall(r'\d+.*[A-Za-z].*?\d{6}.*\d+\S+\d+',line_item_list)
		# print(line_items)
		for line_item in line_items:
			line_item1 = line_item.split()
			print(line_item)
			des = re.search(r'[A-Za-z]+.*?\d{6}',line_item).group()
			qty = line_item1[-3]
			basic = line_item1[-2]


			print(vendor_name)
			print(address)
			print('Invoice No:',invoice)
			print('Inoice Date:',date)
			print('GST No:',gst)
			print('PAN No:',pan)
			print('Tax',tax)
			print('Total Amount:',total)
			print('Description:',des)
			print('Basic Amount:',basic)
			print('Quantity:',qty)

			input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
			# print(input_data)
			print('\n')
			vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
			print(vl)
			vl1 = list(vl.values())
	       
			list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
			# print("list1" , list1)
			# create_excel(list1) ########Testing#############

			if vl1.count(True) == 3:
				print('Validation Successful')
				create_excel(list1)
				print('Invoice data extracted to excel')
			else:
			    print('Exception Occured')


	path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
	for data in os.listdir(path):
		data2 = (path+'\\%s')%data
		if data2.endswith('.pdf'):
			pdf_extraction(data2)
		


evolve_brands()