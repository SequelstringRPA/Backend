from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation



def think_future():
	##---------------fixed_functions_For_excel-----------##

	po_number,state_code = create_workbook()
    ##----------------------------------------##
	def pdf_extraction(data2):
		print(data2)
		global input_data
		header_values = header_fields(data2)
		# print(header_values)
		invoice = header_values[0]
		date = header_values[1]
		gst = header_values[2]
		pan = header_values[3]
		tax = header_values[4]
		total = header_values[5]

		text = header_values[6]
		text1 = header_values[8]
		table = header_values[7]
		text2 = text1.replace('\n',' ')
		# print(text1)
		# print(text)

		try:
			vendor_name = re.search(r'Think Future.*?(Limited|Ltd)',text).group()
		except:
			vendor_name = 'NA'

		try:
			address = re.search(f'(?s){vendor_name}.*?\d{{6}}',text2).group().replace('\n','').replace('  ',' ').strip().split('Address')[-1].replace(':','')
		except:
			address = 'NA'

		date = re.search(r'(?si)DATE.*?(\d+\s+[A-Za-z]+\s+\d+|\d+\/[A-Za-z]+\/\d+|\d+\.[A-Za-z]+\.\d+|\d+\-[A-Za-z]+\-\d+|\d+\s+\d+\s+\d+|\d+\/\d+\/\d+|\d+\.\d+\.\d+|\d+\-\d+\-\d+|\d{1,2}(st|nd|rd|th)\s+[A-Za-z]+\s\d{2,4})',text1).group()
		date = re.search(r'\d+\s+[A-Za-z]+\s+\d+|\d+\/[A-Za-z]+\/\d+|\d+\.[A-Za-z]+\.\d+|\d+\-[A-Za-z]+\-\d+|\d+\s+\d+\s+\d+|\d+\/\d+\/\d+|\d+\.\d+\.\d+|\d+\-\d+\-\d+|\d{1,2}(st|nd|rd|th)\s+[A-Za-z]+\s\d{2,4}',date).group()
		
		invoice = re.search(r'(?si)((Invoice|Bill|Inv)(.|\s)(No|Number|Serial No|#)|Invoice#).*?(([A-Z0-9\\\/\-^s]\d\S+){2,16})',text2.replace(date,'')).group()
		invoice = re.search(r'([A-Za-z]+|\d+)[A-Z0-9\\\/\-]+\d+',invoice).group()

		tax = re.search(r'((IGST|CGST|SGST).*?(\d\S\d+\.\d{2}|\d+\S+\d+))',text).group()
		if 'SGST' in tax or 'CGST' in tax:
			tax = float(re.search(r'\%.*',tax).group().replace('%','').replace(' ','').replace(',','')) * 2
		else:
			tax = re.search(r'\%.*',tax).group().replace('%','').replace(' ','')


		total = re.search(r'(?i)Total.*',text).group().split('Total')[-1].replace(':','').replace(' ','')

		new_list = []
		for list1 in  table:
			for list2 in list1:
				list2 = list(filter(None, list2))
				if list2 != []:
					new_list.append(list2)
		# print(new_list)
		for list2 in new_list:
			for values in list2:
				if 'Description' in values:
					r1 = new_list.index(list2)
					break
				if re.search(r'SGST|CGST|IGST',values):
					r2 = new_list.index(list2)
					break


		print(r1)
		print(r2)
		new_list = new_list[r1+1:r2+1]
		# print(new_list)
		for line_items in new_list:
			# print(line_items)
			des = line_items[1].split('\n',1)[0]
			qty1 = line_items[2].split('\n')
			basic1 = line_items[3].split('\n')
			for qty,basic in zip(qty1,basic1):
				qty = qty.replace(' ','')
				basic = basic.replace(' ','')


				print(vendor_name)
				print(address)
				print('Invoice No:',invoice)
				print('Invoice Date:',date)
				print('GST No:',gst)
				print('PAN No:',pan)
				print('Tax',tax)
				print('Total Amount:',total)
				print('Description:',des)
				print('Basic Amount:',basic)
				print('Quantity:',qty)

				input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
				# print(input_data)
				print('\n')
				vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
				print(vl)
				vl1 = list(vl.values())
		       
				list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
				print("list1" , list1)
				# create_excel(list1)

				if vl1.count(True) == 3:
					print('Validation Successful')
					create_excel(list1)
					print('Invoice data extracted to excel')
				else:
				    print('Exception Occured')


	path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
	for data in os.listdir(path):
		data2 = (path+'\\%s')%data
		if data2.endswith('.pdf'):
			pdf_extraction(data2)
		


think_future()