from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation


def Radius():

    po_number,state_code = create_workbook()
    ##----------------------------------------##


    def pdf_extraction(data2):

        print(data2)
        global input_data
        header_values = header_fields(data2)
        #print(header_values)
        invoice = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]
        text = header_values[6]
        text_t = header_values[7]
        # print(len(text_t[0][6]))
        # print(text)

        for i in range(len(text_t[0][1])):
            if text_t[0][1][i] != None:
                if "Invoice Number" in text_t[0][1][i]:
                    invoice = text_t[0][1][i].split("\n")[-1].strip()

        try:
            vendor_name = re.search(r'(?i)Radius.*?(Limited|Ltd)',text).group()
        except:
            vendor_name = 'NA'
        address = re.search("TAX INVOICE.*?India",re.sub("\n"," ",text)).group().replace("TAX INVOICE","").strip()
        address = re.search("\w+.*?India",address).group()
        regexexp = re.compile("^Lower")
        if regexexp.search(address):
            address = "E-48/9," + address 
        Description_list = re.findall(r"^\d\d?\s.*?\n", text, flags=re.MULTILINE)
        for i in range(len(Description_list)):
            des = re.search("\w+.*?\d\s",Description_list[i]).group().split()
            del des[-1]
            del des[0]
            des = " ".join(des)
            qty = Description_list[i].split()[-13]
            basic = Description_list[i].split()[-11]
            if float(Description_list[i].split()[-2]) == 0.00:
                tax = float(Description_list[i].split()[-4]) + float(Description_list[i].split()[-6])
            else:
                # print(type(Description_list[i].split()[-2]))
                tax = Description_list[i].split()[-2]

            print(vendor_name)
            print(address)
            print('Invoice No:',invoice)
            print('Invoice Date:',date)
            print('GST No:',gst)
            print('PAN No:',pan)
            print('Tax',tax)
            print('Total Amount:',total)
            print('Description:',des)
            print('Basic Amount:',basic)
            print('Quantity:',qty)

            input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
            # print(input_data)
            print('\n')
            vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
            print(vl)
            vl1 = list(vl.values())
           
            list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
            print("list1" , list1)
            # create_excel(list1)

            if vl1.count(True) == 3:
                print('Validation Successful')
                create_excel(list1)
                print('Invoice data extracted to excel')
            else:
                print('Exception Occured')

       

    ##-------------------------Proccess_Intial--------------------------##
    path = os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
    for data in os.listdir(path):
        data2 = (path+'\\%s')%data
        if data2.endswith('.pdf'):
            pdf_extraction(data2)

Radius()
