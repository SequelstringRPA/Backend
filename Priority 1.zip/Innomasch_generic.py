from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation



def Innomasch():

    po_number,state_code = create_workbook()
    ##----------------------------------------#


    def extraction_process(file):
        print(file)
        global input_data

        header_values = header_fields(file)
        invoice = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]
        text = header_values[6].replace('\n','')
        text1 = header_values[8]
        text2 = text1.replace('\n',' ')
        # print(text2)
        #################

        try:
            vendor_name = re.search(r'(?i)Innomasch.*?(Limited|Ltd)',text).group()
        except:
            vendor_name = 'NA'

        try:
            address = re.search(f'(?s){vendor_name}.*?\d{{6}}',text2).group().replace('\n','').replace('  ',' ').strip()
        except:
            address = 'NA'

        
        if invoice == 'NA':
            invoice = re.search("#.*?Place", text).group().replace("Place", "").replace("#","").split()[-1].strip()


        DESCRIPTION_List=[]
        vals_list =[]
        DESCRIPTION_string = re.search("Amount.*?Sub", text).group().replace("Amount", "").replace("Sub","")
        DESCRIPTION_string = re.findall(".*?\d+?,?\d+?,?\d+\.\d+\s\d+\%\s\d+?,?\d+?,?\d+\.\d+\s\d+?,?\d+?,?\d+\.\d+", DESCRIPTION_string)
        # print(DESCRIPTION_string)
 
        for i in range(len(DESCRIPTION_string)):
            qty = DESCRIPTION_string[i].split()[-5]
            basic = DESCRIPTION_string[i].split()[-4]
            des = DESCRIPTION_string[i].split(qty)[0]
         

            print(vendor_name)
            print(address)
            print('Invoice No:',invoice)
            print('Invoice Date:',date)
            print('GST No:',gst)
            print('PAN No:',pan)
            print('Tax',tax)
            print('Total Amount:',total)
            print('Description:',des)
            print('Basic Amount:',basic)
            print('Quantity:',qty)

            input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
            # print(input_data)
            print('\n')
            vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
            print(vl)
            vl1 = list(vl.values())
           
            list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
            print("list1" , list1)
            # create_excel(list1)

            if vl1.count(True) == 3:
                print('Validation Successful')
                create_excel(list1)
                print('Invoice data extracted to excel')
            else:
                print('Exception Occured')


    ##-------------------------Proccess_Intial--------------------------##
    path = os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
    for file1 in os.listdir(path):
        file=(path+'\%s')%file1
        if file.endswith('.pdf'):
            extraction_process(file)

Innomasch()
