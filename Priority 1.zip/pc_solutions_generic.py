from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation


def pcsolutions():
	##---------------fixed_functions_For_excel-----------##

	po_number,state_code = create_workbook()
    ##----------------------------------------##
	def pdf_extraction(data2):
		print(data2)
		global input_data
		header_values = header_fields(data2)
		# print(header_values)
		invoice = header_values[0]
		date = header_values[1]
		gst = header_values[2]
		pan = header_values[3]
		tax = header_values[4]
		total = header_values[5]

		text = header_values[6]
		table = header_values[7]
		# text1 = header_values[8]
		# text2 = text1.replace('\n',' ')
		# print(table)
		# print(text)

		try:
			vendor_name = re.search(r'PC Solutions.*?(Limited|Ltd)',text).group()
		except:
			vendor_name = 'NA'

		try:
			try:
				address = re.search(r'(?s)Duplicate.*?\d{6}',text).group().split('\n',1)[-1].replace('\n',' ').replace('  ',' ').strip()
			except:
				address = re.search(f'(?s){vendor_name}.*?\d{{6}}',text).group().replace('\n','').replace('  ',' ').strip()
		except:
			address = 'NA'

		invoice_list = table[0][3]
		try:
			# print(invoice_list)
			for values in invoice_list:
				if values != None :
					values = values.replace('\n',' ').strip()
					if re.search(r'Invoice Number.*?\d+',str(values)):
						invoice = re.search(r'Invoice Number.*?\d+',str(values)).group()
						invoice = re.search(r'\d+',invoice).group()
						break
		except:
			invoice = invoice

		try:
			for values in invoice_list:
				if values != None:
					values = values.replace('\n',' ').strip()
					# print(values)
					if re.search(r'Invoice Date',values):
						date = re.search(r'\d+\S+\d+',values).group()
		except:
			date = date

		try:
			tax1 = re.search(r'Total Amount \[INR].*\n.*',text).group().replace('Total Amount [INR]','').split()
			tx = 0
			if len(tax1) == 5:
				del tax1[0]
				del tax1[-1]
				if len(tax1) == 3:
					for amt in tax1:
						amt = amt.replace(',','')
						tax = tx + float(amt)

		except:
			tax = re.search(r'(?i)\d+\S\d+.*\n.*?Round Off',text).group().split('\n')[0].split()[1]

		try:
			line_item_list = re.search(r'(?si)Description.*?Total Amount \[INR]',text).group()
		except:
			line_item_list = re.search(r'(?si)Description.*?Round Off',text).group()
		# print(line_item_list)
		line_items = re.findall(r'\d+.*?[A-Za-z)].*?\d{4,6}.*?\.\d{2}.*?\.\d{2}',line_item_list)
		for line_item in line_items:
			# print(line_item)
			des1 = re.search(r'\d+.*?[A-Za-z)].*?\d{4,6}',line_item).group()
			des = des1[2:]
			line_item1 = line_item.replace(des1,'').split()
			# print(line_item1)
			if len(line_item1) == 3:
				qty = line_item1[0]
				basic = line_item1[2]
			else:
				item = re.search(r'.*[A-Za-z]',line_item).group()
				line_item = line_item.replace(item,'').split()
				# print(line_item)
				qty = line_item[0]
				basic = line_item[1]

			print(vendor_name)
			print(address)
			print('Invoice No:',invoice)
			print('Invoice Date:',date)
			print('GST No:',gst)
			print('PAN No:',pan)
			print('Tax',tax)
			print('Total Amount:',total)
			print('Description:',des)
			print('Basic Amount:',basic)
			print('Quantity:',qty)

			input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
			# print(input_data)
			print('\n')
			vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
			print(vl)
			vl1 = list(vl.values())
	       
			list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
			print("list1" , list1)
			# create_excel(list1)

			if vl1.count(True) == 3:
				print('Validation Successful')
				create_excel(list1)
				print('Invoice data extracted to excel')
			else:
			    print('Exception Occured')


	path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
	for data in os.listdir(path):
		data2 = (path+'\\%s')%data
		if data2.endswith('.pdf'):
			pdf_extraction(data2)
		


pcsolutions()