from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation

def Searce():

    po_number,state_code = create_workbook()
    ##----------------------------------------##

    def pdf_extraction(data2):

        print(data2)
        global input_data
        header_values = header_fields(data2)
        #print(header_values)
        invoice = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]
        text = header_values[6]
        text_t = header_values[7]
        # print(text)

        try:
            vendor_name = re.search(r'(?i)Searce.*?(Limited|Ltd)',text).group()
        except:
            vendor_name = 'NA'
        address = re.search("Tax Invoice.*?\n.*?\n.*?\n.*?\n",text).group().replace("Tax Invoice","").replace("\n"," ").strip()
        invoice = re.search("\d{9}",address).group()
        address = re.sub(invoice,"",address)
        date = re.findall("\d?\d/\d?\d/\d{4}",text)[0]

        des_str = re.search("AMOUNT\n(.*?\n.*?)+",text).group()
        des_str = re.findall("^\d{6}\s.*?\n",des_str,flags=re.MULTILINE)

        for line_item in des_str:
            des = re.search("\w+.*?\d",line_item).group().split()
            del des[-1]
            des = " ".join(des)
            qty = line_item.split()[-4]
            basic = line_item.split()[-3]
            # print(qty,basic)

            print(vendor_name)
            print(address)
            print('Invoice No:',invoice)
            print('Invoice Date:',date)
            print('GST No:',gst)
            print('PAN No:',pan)
            print('Tax',tax)
            print('Total Amount:',total)
            print('Description:',des)
            print('Basic Amount:',basic)
            print('Quantity:',qty)

            input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
            # print(input_data)
            print('\n')
            vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
            print(vl)
            vl1 = list(vl.values())
           
            list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
            print("list1" , list1)
            # create_excel(list1)

            if vl1.count(True) == 3:
                print('Validation Successful')
                create_excel(list1)
                print('Invoice data extracted to excel')
            else:
                print('Exception Occured')
          
    ##-------------------------Proccess_Intial--------------------------##
    path = os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
    for data in os.listdir(path):
        data2 = (path+'\\%s')%data
        if data2.endswith('.pdf'):
            pdf_extraction(data2)

Searce()
