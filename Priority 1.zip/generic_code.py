import pdfplumber
import os, shutil,io
import datetime
import re
from io import StringIO
from itertools import zip_longest
import fitz


def header_fields(data2):
    # def data_extraction(data2):
    global invoice,date,gst,pan,tax,total

    with fitz.open(data2) as doc:
        text_fitz = ''
        for page in doc:
            text_fitz+= page.getText()
    # print(text_fitz)

    with pdfplumber.open(data2) as pdf:
        pages = pdf.pages
        text = ''
        text_t = []
        for i in range(0,len(pages)):
            try:
                page = pages[i]
                text1 = page.extract_text(x_tolerance=3, y_tolerance=3)
                # print(text1)
                if text1 != None:
                    text = text + text1
                table = page.extract_tables(table_settings = {"text_tolerance": 4,"vertical_strategy": "lines","keep_blank_chars": False})
                text_t = text_t + table
            except:
                pass
    # print (text)
    # print(text_t)
    print('\n')
    data_dict = {}
    l = ['.', '%', ',', '\n', ' ']
    y = []

    # addr = data_extractor_alphanumeric(text_miner,'Ltd.',1,data_dict,'Ship','Address',l,'','')
    # print(addr)

    gstin_list = ['37AAACH0812J2ZU','10AAACH0812J1ZB','04AAACH0812J1Z4','22AAACH0812J2Z5','07AAACH0812J1ZY','07AAACH0812J2ZX','24AAACH0812J1Z2','06AAACH0812J1Z0',
                '20AAACH0812J1ZA','29AAACH0812J2ZR','32AAACH0812J2Z4','23AAACH0812J2Z3','27AAACH0812J2ZV','21AAACH0812J1Z8',
                '03AAACH0812J2Z5','08AAACH0812J1ZW','33AAACH0812J2Z2','36AAACH0812J1ZX','09AAACH0812J1ZU','05AAACH0812J1Z2','19AAACH0812J2ZS']


    gst_list = re.findall(r'(?si)(GSTIN|GSTIN (NO|Number)|GSTNO|GSTN|GST (NO|Number)|GST\s+Reg\s+No).*?([A-Z0-9]{15})',text)
    # print(gst_list)
    gst_list1 = []
    for values in gst_list:
        # print(values)
        for value in values:
            try:
                value = re.search(r'\d{2}[A-Z0-9]{13}',value).group()
                # print(value)
                if value not in gst_list1:
                    gst_list1.append(value)
            except:
                pass

    for gstin_no in gstin_list:
        for gst_no in gst_list1:        
            if gstin_no.strip() == gst_no.strip():
                # print(gstin_no)
                gst_list1.remove(gstin_no)

    # print('NEW LIST',gst_list1)
    # print('LLLLLLLLLLLLLLLLL',len(gst_list1))

    try:
        gst = gst_list1[0].strip()
    except:
        gst = "NA"
    # print('GST NO:',gst)

    # check =  any(item in gstin_list for item in gst_list1)
    # if check == True:
    #     print(item)

    pan_list = re.findall(r'(?s)(PAN|PAN NO|Pan No|PAN No).*?([0-9A-Z]{10})',text)
    # print(pan_list)
    pan_list1 = []
    for values in pan_list:
        # print(values)
        for value in values:
            try:
                value = re.search(r'[A-Z]{5}\d{4}[A-Z]',value).group()
                # print(value)
                if value not in pan_list1:
                    pan_list1.append(value)
            except:
                pass

    for pan_no in pan_list1:
        if pan_no.strip() == 'AAACH0812J':
            pan_list1.remove(pan_no)

    # print('NEW PAN LIST',pan_list1)

    try:
        pan = pan_list1[0].strip()
    except:
        pan ="NA"
    # print('PAN NO:',pan)


    # if gst[2:12] == pan and len(gst) == 15 and len(pan) == 10:
    #     print('GST and PAN No. Correct')

    try:
        inv_no_list = re.search(r'(?si)((Invoice|Bill|Inv)(.|\s)(No|Number|Serial No|#)|Invoice#).*?(([A-Z0-9\\\/\-^s]\d\S+){2,16})',text_fitz).group()    #(?si)(Invoice|Inv|Bill) (No|Number).*?(\d+[A-Z0-9\\\/\-^s]+\d+|\d+)
        # print('FITZ',inv_no_list) 
        invoice = re.search(r'([A-Za-z]+|\d+)[A-Z0-9\\\/\-]+\d+',inv_no_list).group()
        # 
    except:
        invoice = 'NA'
    # print('Invoice No:',invoice)
    textd = text.replace(invoice,'')
    try:
        date_list = re.findall(r'(?si)(((Invoice|Bill|Inv) (Dt|Date)|Dated|Dt).*?(\d+\s+[A-Za-z]+\s+\d+|\d+\/[A-Za-z]+\/\d+|\d+\.[A-Za-z]+\.\d+|\d+\-[A-Za-z]+\-\d+|\d+\s+\d+\s+\d+|\d+\/\d+\/\d+|\d+\.\d+\.\d+|\d+\-\d+\-\d+|\d{1,2}(st|nd|rd|th)\s+[A-Za-z]+\s\d{2,4}))',textd)[0]#.group()
        # print(date_list)
        for dates in date_list:
            # print(dates)
            if re.search(r'\d+\s+[A-Za-z]+\s+\d+|\d+\/[A-Za-z]+\/\d+|\d+\.[A-Za-z]+\.\d+|\d+\-[A-Za-z]+\-\d+|\d+\s+\d+\s+\d+|\d+\/\d+\/\d+|\d+\.\d+\.\d+|\d+\-\d+\-\d+|\d{1,2}(st|nd|rd|th)\s+[A-Za-z]+\s\d{2,4}',dates):
                date = re.search(r'\d+\s+[A-Z]([a-z]+|[A-Z]+)\s+\d+|\d+\/[A-Z]([a-z]+|[A-Z]+)\/\d+|\d+\.[A-Z]([a-z]+|[A-Z]+)\.+\d+|\d+\-[A-Z]([a-z]+|[A-Z]+)\-\d+|\d+\s+\d+\s+\d+|\d+\/\d+\/\d+|\d+\.\d+\.\d+|\d+\-\d+\-\d+|\d{1,2}(st|nd|rd|th)\s+[A-Za-z]+\s\d{2,4}',dates).group() 
                # print(date)         
    except:
        date = 'NA'
    # print('Invoice Date:',date)

    try:
        tax_amount = re.findall(r'((Total (Tax Amount|GST|Tax |Tax amt))|Taxes|((IGST.*?INR|IGST.*?%|IGST)|((SGST|State GST).*?%|S(?i)GST|State GST)|((CGST|Central GST).*%|C(?i)GST|Central GST))).*?(\d\S\d+\.\d{2}|\d+\S+\d+)',text)[0]#.group()
        for t in list(tax_amount):
            if 'SGST'.casefold() in t.casefold() or 'CGST'.casefold() in t.casefold() or 'State GST'.casefold() in t.casefold() or 'Central GST'.casefold() in t.casefold():
                # print(tax_amount)
                tax1 = tax_amount[-1].replace(',','')
                tax = 2*float(tax1)
                break
        else:
            tax = tax_amount[-1]
    except:
        tax = 'NA'
    # print('Total Tax:',tax)

    try:
        sub_total = re.search(r'(?i)(Sub Total.*|Subtotal.*)',text).group()
        text2 = text.replace(sub_total,'')

    except:
        text2 = text
    # print(text2)
    
    try:
        try:
            total_list = re.search(r'(((Total|TOTAL|Gross) (Amount|Invoice Amount|Value|Invoice Value|Amount Due|TAX INVOICE|\(INR\)|CHARGES|Charges))|Balance (Due|Payable)|(Grand|Invoice) Total).*?(\d+\,\S+\d+|\d+\S\d+\.\d{2}|\d+\S\d+\.\d{1})',text2).group()
            # print(total_list)
        except:
            try:
                total_list = re.search(r'(TOTAL|Total).*?[A-Za-z]+.*?(\d+\,\S+\d+|\d+\S\d+\.\d{2})',text2).group()
                extra_info = re.search(r'(TOTAL|Total).*?[A-Za-z]+',total_list).group()
                total_list = total_list.replace(extra_info,'')

            except:
                total_list = re.search(r'(TOTAL|Total).*?(\d+\,\S+\d+|\d+\S\d+\.\d{2})',text2).group()
    except:
        total_list = ''
    # print(total_list)

    try:
        total = re.search(r'\d+\,\S+\d+|\d+\S\d+\.\d{2}|\d+\S\d+\.\d{1}',total_list).group().strip()
    except:
        total = 'NA'
    # print('Total Amount:',total)

    # return "Success"


    return invoice,date,gst,pan,tax,total,text,text_t,text_fitz
            # print(invoice,date,gst,pan,tax,total)


# path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
# for data in os.listdir(path):
#     data2 = (path+'\\%s')%data
#     if data2.endswith('.pdf'):
#         header_fields(data2)
