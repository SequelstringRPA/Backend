from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation



def Threei_infotech():

    po_number,state_code = create_workbook()
    ##----------------------------------------##

    def pdf_extraction(file):
        print(file)
        global input_data
        ## GENERIC ##
        header_values = header_fields(file)
        invoice = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]
        text = header_values[6].replace('\n',' ')
        text1 = header_values[8]
        text2 = text1.replace('\n',' ')
        # print(text2)
        # print(text)

        #################

        try:
            vendor_name = re.search(r'(?i)3i.*?(Limited|Ltd)',text).group()
        except:
            vendor_name = 'NA'

        try:
            address = re.search(f'(?s){vendor_name}.*?\d{{6}}',text2).group().replace('\n','').replace('  ',' ').strip()
        except:
            address = 'NA'

        pan = gst[2:12]


        if re.search(r'Amount\s{0,}in\s{0,}INR(.*?)Amount\s{0,}Chargeable', text):
            desc = re.search(r'Amount\s{0,}in\s{0,}INR(.*?)Amount\s{0,}Chargeable', text).group(1)
            # print(desc)
            f = r'SAC\s{0,}Code\s{0,}:\s{0,}\d*.*?\s'
            spl = re.split(f, desc)
            # print(spl)

             ##-----------------DESC____QTY______BASIC-----------------##
            for a in spl:
                # print(a)
                ##______________TO find of basix-----##
                if re.search(r'\d{1}.*?[.]\d{2}', a) and 'IGST' not in a:
                    b = re.search(r'\d{1}.*?[.]\d{2}', a).group()
                    # print(d)
                    c = b.split()
                    index = c[-1]
                    # print(index)

                    f = a.split()
                    # print(f)
                    for g in f:
                        # print(g)
                        ##______________TO find of index basix-----##
                        if g == index:
                            m = f.index(g)
                            break

                    basic = f[m]
                    qty = f[m - 1]
                    # print(qty)
                    # print(basic)
                    DES = f[:m - 1]
                    des = ''
                    for s in DES:
                        des += str(s)
                        des += ' '


                    print(vendor_name)
                    print(address)
                    print('Invoice No:',invoice)
                    print('Invoice Date:',date)
                    print('GST No:',gst)
                    print('PAN No:',pan)
                    print('Tax',tax)
                    print('Total Amount:',total)
                    print('Description:',des)
                    print('Basic Amount:',basic)
                    print('Quantity:',qty)

                    # input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
                    # print(input_data)
                    # print('\n')
                    # vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
                    # print(vl)
                    # vl1 = list(vl.values())
                   
                    list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
                    print("list1" , list1)
                    create_excel(list1)

                    # if vl1.count(True) == 3:
                    #     print('Validation Successful')
                    #     create_excel(list1)
                    #     print('Invoice data extracted to excel')
                    # else:
                    #     print('Exception Occured')
              

        
   
    ##-------------------------Proccess_Intial--------------------------##
    path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
    for data in os.listdir(path):
        data2 = (path+'\\%s')%data
        if data2.endswith('.pdf'):
            pdf_extraction(data2)


Threei_infotech()
