import os
import openpyxl
from openpyxl import load_workbook


def create_workbook():
	global workbook_name,page,wb
	file_loc = os.path.join(os.getcwd(),"Processed").replace(r"\Codes","")
	po_number = ''
	state_code = ''   
	fields=['VENDOR NAME','PO NUMBER','ADDRESS','state_code','TAX AMOUNT','INVOICE NUMBER','GSTIN NO.','INVOICE DATE','DESCRIPTION OF GOODS','QUANTITY','BASIC AMOUNT','TOTAL AMOUNT','PAN NO.'] # Standard List for each extraction
	workbook_name=file_loc+"/invoice_data.xlsx"##PATH FOR STORING XLSX FILE
	wb = openpyxl.Workbook()
	page = wb.active
	page.append(fields)
	wb.save(workbook_name)

	return po_number,state_code

##-----------Append_data_to_Excel----------##
def create_excel(list1):
	openpyxl.load_workbook(workbook_name)
	for info in list1:
		page.append(info)
	wb.save(workbook_name)
	print("saved")
    ##----------------------------------------##

    