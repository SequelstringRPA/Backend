import pandas as pd
import numpy as np
import datetime
from dateutil import parser
import re

def valid_data(lst):
	temp = {}

	df = pd.read_excel(r"E:\IS_Billing\Vendor_Portal_Report\Vendor SystemHero MotoCorp.xlsx",index_col=None,skiprows=[0])
	# df = pd.read_excel(r"C:\Users\Jojo\Desktop\Hero IS Billing\Download PDF\Vendor_Portal_Report\Vendor SystemHero MotoCorp.xlsx",index_col=None,skiprows=[0])

	
	#-----------Date_Conversion---------#
	new_date_df = []
	date_df = df['Invoice Date'].values
	# print(date_df)

	new_amt_df = []
	new_amt_df1 = []
	amt_df = df['Amount'].values
	# print(amt_df)
	for a in amt_df:
		amt = re.search(r'\d+\S+\d+',str(a).replace(',','')).group()
		new_amt_df.append(amt)

		amt1 = re.search(r'\d+',str(a).replace(',','')).group()
		new_amt_df1.append(amt1)
	new_amt_df = np.array(new_amt_df)
	new_amt_df1 = np.array(new_amt_df1)
	# print('**##',new_amt_df)
	# print('**##',new_amt_df1)

	for i in date_df:
		# print(i)
		index = np.where(i == date_df)[0][0]
		# print(index)
		# print(date_df[index])

		for p in date_df[index].splitlines():
			# print(p)
			d = parser.parse(p,dayfirst=True)
			# print(d)
			z=d.strftime("%d.%m.%Y")
		# print(z)
			
		new_date_df.append(z)
	new_date_df = np.array(new_date_df)
	# print('**##',new_date_df)

	dt = lst[5]
	for p in dt.splitlines():
		# print(p)
		d = parser.parse(p,dayfirst=True)
		# print(d)
		dt2=d.strftime("%d.%m.%Y")
	# print(dt2)

	# #----------------------------------#
	
	##Invoice Number Validation
	def inv():
		inv = df[df['Invoice No.'].apply(str) == lst[3]]
		# print(inv)  
		if len(inv) != 0:
			return  True
		else:
			return False

	def total():
		lst[9] = lst[9].replace(',','').strip()
		lst[9] = re.search(r'\d+',lst[9]).group()
		try:
			total = df[new_amt_df == lst[9]]
		except:
			total = df[new_amt_df1 == lst[9]]
		# print(total)
		if len(total) != 0:
			return True
		else:
			return False

	def date():
		# print(new_date_df)
		date = df[(new_date_df == dt2) & (df['Invoice No.'].apply(str) == lst[3])]
		if len(date) != 0:
			return True
		else:
			return False


	q = inv()
	if q == True:
		# temp.append(q)
		temp['Invoice No.'] = q
	else:
		# temp.append(q)
		temp['Invoice No.'] = q
		print('Invoice Number Validation "Failed!!"')

	w = total()
	if w == True:
		# temp.append(w)
		temp['Total Amount'] = w
	else:
		# temp.append(w)
		temp['Total Amount'] = w
		print('Total Amount Validation "Failed!!"')

	e = date()
	if e == True:
		# temp.append(e)
		temp['Invoice Date'] = e
	else:
		temp['Invoice Date'] = e
		print('Date Validation "Failed!!"')
	

	return temp

# lst = ['Vodafone Idea Limited', 'SumanTower, Plot No 18, Sector no 11, Gandhinagar 382011', '21,890', 'EIBH091900018160', '10AAACB2100P1ZC', '01.10.19', '', 1, '121,612', '143,503', 'AAACB2100P']
# x = valid_data(lst)
# print(x)