from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation

def schneider():
	##---------------fixed_functions_For_excel-----------##

	po_number,state_code = create_workbook()
    ##----------------------------------------##
	def pdf_extraction(data2):
		print(data2)
		global input_data
		header_values = header_fields(data2)
		# print(header_values)
		invoice = header_values[0]
		date = header_values[1]
		gst = header_values[2]
		pan = header_values[3]
		tax = header_values[4]
		total = header_values[5]

		text = header_values[6]
		text1 = header_values[8]
		text2 = text1.replace('\n',' ')
		table = header_values[7]
		# print(table)
		# print(text2)
		# print(text)

		try:
			vendor_name = re.search(r'(?i)SCHNEIDER.*?(Limited|Ltd)',text2).group()
		except:
			vendor_name = 'NA'

		try:
			address = re.search(f'(?s){vendor_name}.*?\d{{6}}',text2).group().replace('\n','').replace('  ',' ').replace(vendor_name,'').strip()
			address = re.split('Ltd|LTD|Limited|LIMITED',address)[-1].strip()
		except:
			address = 'NA'

		if re.search(r'Grand Total.*\d+\S\d+',text):
			amount_list = re.search(r'Grand Total.*\d+\S\d+',text).group()
			amount_list = re.findall(r'\d+\S+\.\d{2}',amount_list)
			# print(amount_list)
			total = amount_list[-1]
			if len(amount_list) == 3:
				tax = amount_list[-2]
			elif len(amount_list) == 4:
				tax = float(amount_list[-2].replace(',','')) + float(amount_list[-3].replace(',',''))
		else:
			total = total
			tax1 = re.search(r'Taxable Value.*\n.*?Total.*\d+\S+\d+',text).group().replace(' ,',',').split('   ',1)[-1]
			if re.search(r'\s\d\s\d+\S+',tax1):
				tax2 = re.search(r'\s\d\s\d+\S+',tax1).group()
				tax3 = tax2.replace(' ','')
				tax1 = tax1.replace(tax2,tax3)
			tax1 = tax1.replace(',','').split()
			# print(tax1)
			tax = sum([float(i) for i in tax1]) 

		new_list = []
		for list1 in  table:
			for list2 in list1:
				list2 = list(filter(None, list2))
				if list2 != []:
					new_list.append(list2)
		# print(new_list)
		for list2 in new_list:
			for values in list2:
				if 'Description of' in values:
					r1 = new_list.index(list2)
					break
				if re.search('Grand Total',list2[0]) or re.search(r'Total.*?\.\d{2}.*\.\d{2}',values):
					r2 = new_list.index(list2)
					break


		print(r1)
		print(r2)
		new_list = new_list[r1+2:r2]
		# print(new_list)

		for line_items in new_list:
			if len(line_items) >5:
				print(line_items)
				des = (line_items[1] + ' ' + line_items[2]).replace('\n',' ')
				if re.search(r'\d+',line_items[3]):
					qty = re.search(r'\d+',line_items[3]).group()
					basic = line_items[4]
				elif re.search(r'\d+',line_items[4]):
					qty = re.search(r'\d+',line_items[4]).group()
					basic = line_items[5]

				# print(vendor_name)
				# print(address)
				# print('Invoice No:',invoice)
				# print('Invoice Date:',date)
				# print('GST No:',gst)
				# print('PAN No:',pan)
				# print('Tax',tax)
				# print('Total Amount:',total)
				print('Description:',des)
				print('Basic Amount:',basic)
				print('Quantity:',qty)

				input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
				# print(input_data)
				print('\n')
				vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
				print(vl)
				vl1 = list(vl.values())
		       
				list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
				print("list1" , list1)
				# create_excel(list1)

				if vl1.count(True) == 3:
					print('Validation Successful')
					create_excel(list1)
					print('Invoice data extracted to excel')
				else:
				    print('Exception Occured')


	path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
	for data in os.listdir(path):
		data2 = (path+'\\%s')%data
		if data2.endswith('.pdf'):
			pdf_extraction(data2)
		


schneider()