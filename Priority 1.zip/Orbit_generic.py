from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation


def Orbit():

    po_number,state_code = create_workbook()


    def pdf_extraction(data2):

        print(data2)
        global input_data
        header_values = header_fields(data2)
        #print(header_values)
        invoice = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]
        text = header_values[6]
        text_t = header_values[7]

        invoice = re.search("Invoice No.*?Customer",text).group().split()[-2]
        total=re.findall("Total.*?\d+\.\d+",text)[-1].split()[-1]

        try:
            vendor_name = re.search(r'(?i)Orbit.*?(Limited|Ltd)',text).group()
        except:
            vendor_name = 'NA'
        address = re.search("Registered Office.*?Web",re.sub("\n"," ",text_t[0][0][0])).group().replace("Registered Office","").replace("Web","")


        for i in range(len(text_t[0][6][1].split("\n"))):
            des = text_t[0][6][2].split("\n",len(text_t[0][6][1].split("\n"))-1)[i]
            des = re.sub("\n"," ",des)
            qty = text_t[0][6][6].split("\n")[i].strip()
            basic = text_t[0][6][8].split("\n")[i].strip()

            print(vendor_name)
            print(address)
            print('Invoice No:',invoice)
            print('Invoice Date:',date)
            print('GST No:',gst)
            print('PAN No:',pan)
            print('Tax',tax)
            print('Total Amount:',total)
            print('Description:',des)
            print('Basic Amount:',basic)
            print('Quantity:',qty)

            input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
            # print(input_data)
            print('\n')
            vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
            print(vl)
            vl1 = list(vl.values())
           
            list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
            print("list1" , list1)
            # create_excel(list1)

            if vl1.count(True) == 3:
                print('Validation Successful')
                create_excel(list1)
                print('Invoice data extracted to excel')
            else:
                print('Exception Occured')


    path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
    for data in os.listdir(path):
        data2 = (path+'\\%s')%data
        if data2.endswith('.pdf'):
            pdf_extraction(data2)

Orbit()
