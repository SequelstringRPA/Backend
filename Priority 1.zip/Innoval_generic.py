from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation


def Innoval():

    po_number,state_code = create_workbook()
    ##----------------------------------------##



    def extract_pdf_df_tabula(pdf_path):
        df = tabula.read_pdf(pdf_path, pages='all')[0]
        return df

    def plumber(file):
        with pdfplumber.open(file)as pdf:
            page = pdf.pages
            text=''
            for i ,pg in enumerate(page):
                text1=page[i].extract_text()
                text1=text1.replace('\n',' ')
                text=text+text1

            return text          # printing text

    def get_index(df, string):
        for i in range(0, df.shape[1]):
            for j in range(0, df.shape[0]):
                # print(type(df._get_value(j, i, takeable = True)))
                strg = str(df._get_value(j, i, takeable = True))   
                if string in strg:
                    return j, i
                    break

    def get_description(df, start, split):
        DESCRIPTION_List  = []
        DESCRIPTION = ""
        vals_list = []
        flg = 0
        i_copy = 0
        for i in range(start, df.shape[0]-1):
            if pd.isnull(df._get_value(i, 0, takeable = True)):
                DESCRIPTION_List.append(DESCRIPTION[2:])
                i_copy = i
                break
            if pd.notnull(df._get_value(i, 1, takeable = True)) and len(df._get_value(i, 1, takeable = True).split()) == split:
                vals = df._get_value(i, 1, takeable = True).split()
                vals_list.append(vals)
                if flg == 1:
                    DESCRIPTION_List.append(DESCRIPTION[2:])
                DESCRIPTION = ""
                DESCRIPTION =  DESCRIPTION + df._get_value(i, 0, takeable = True)
                flg = 1
            if pd.isnull(df._get_value(i, 1, takeable = True)):
                DESCRIPTION = DESCRIPTION + " " + df._get_value(i, 0, takeable = True)
        return DESCRIPTION_List, vals_list


    def plumber_table(file):
        with pdfplumber.open(file)as pdf:
            table = page.extract_tables(table_settings = {"text_tolerance": 3,"vertical_strategy": "text","horizontal_strategy": "text","keep_blank_chars": False,})

            text=''
            for i ,pg in enumerate(table):
                text1=table[i].extract_text()
                text1=text1.replace('\n',' ')
                text=text+text1
            return text          # printing text



    def extraction_process(file):
        global VENDOR, ADDRESS,TAX_AMOUNT, INVOICE_NUM, GSTIN_NO, INVOICE_DATE, DESCRIPTION, QUANTITY, BASIC_AMOUNT, TOTAL_AMOUNT, PAN, input_data

        text = plumber(file)
        df = extract_pdf_df_tabula(file)


        header_values = header_fields(file)
        invoice = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]
    
        VENDOR =  "Innoval Digital Solutions Pvt Ltd (IVL)"
        ADDRESS = "5Th Floor , Thejaswini Technopark Trivandrum Kerala 695581 India"
        INVOICE_NUM = invoice
        GSTIN_NO = gst
        PAN = pan
        
        INVOICE_DATE = date
        TAX_AMOUNT = tax
        TOTAL_AMOUNT = total

        r, c = get_index(df, "Item & Description")
        DESCRIPTION_List, vals_list = get_description(df, r+1, 5)

        
                  
        # print('\n')
        # vl = validation.valid_data(input_data)# function call
        # print(vl)
        # vl1 = list(vl.values())

        input_data = []

        for i in range(len(DESCRIPTION_List)):
            input_data.append([VENDOR, po_number, ADDRESS, state_code, TAX_AMOUNT, INVOICE_NUM, GSTIN_NO, INVOICE_DATE,DESCRIPTION_List[i], vals_list[i][0], vals_list[i][1], TOTAL_AMOUNT, PAN])
        print(input_data)
        # input_data = [[VENDOR,po_number,ADDRESS,state_code,TAX_AMOUNT,INVOICE_NUM,GSTIN_NO,INVOICE_DATE,DESCRIPTION,QUANTITY,BASIC_AMOUNT,TOTAL_AMOUNT,PAN]]
        # if vl1.count(True) == 3:
        create_excel(input_data)
        # else:
        # print('Exception Occured')

    output_folder = r"C:\Users\AbhigyanSS\Desktop\proj\Solutions and Insights\Invoices and Do"
    ##-------------------------Proccess_Intial--------------------------##
    path = os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
    for file1 in os.listdir(path):
        file=(path+'\%s')%file1
        if file.endswith('.pdf'):
            print(file)
            extraction_process(file)

Innoval()
