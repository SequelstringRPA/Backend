from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation



def Azucane():

    po_number,state_code = create_workbook()
    ##----------------------------------------##


    def pdf_extraction(file):
        print(file)
        global input_data
        ## GENERIC ##
        header_values = header_fields(file)
        invoice = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]
        text = header_values[6].replace('\n',' ')
        text1 = header_values[6]
        # text_tab = header_values[7]
        # print(text_tab)
        # print(text1)
        #################

        vendor_name =  re.search(r'(?i)Azucane.*?(Ltd|Limited)',text).group()
        address = re.search(r'(?i)Registered Address.*?Email',text).group().split('Address',1)[-1].replace('Email','').strip().replace('  ','').replace(vendor_name,'')

        line_item_list = re.search(r'(?si)Description.*?(SUB TOTAL|IGST)',text1).group()
        line_item_list1 = re.search(r'(?s)Service No.*?(SUB TOTAL|IGST)',line_item_list).group()

        # print(line_item_list1)
        line_items = re.findall(r'[A-z]+.*\d+\S+\.\d{2}',line_item_list1)
        for line_item in line_items:
            line_item1 = re.search(r'[A-Za-z].*?\.\d{2}',line_item).group()
            # print(line_item1)
            line_item = line_item.strip().split(line_item1)
            lineitem = line_item[-1].strip().replace('  ',' ').split()
            # print(lineitem)
            # print(len(lineitem))
            if len(lineitem) == 2:
                basic = re.search(r'\d+\S+\d+(?!.*\d+\S+\d+)',line_item1).group().strip()  #######match last occurence
                des = line_item1.replace(basic,'').strip()
                qty = lineitem[0]
            if len(lineitem) == 1:
                basic = lineitem[0]
                qty = re.search(r'\d+\S+\d+(?!.*\d+\S+\d+)',line_item1).group().strip()  #######match last occurence
                des = line_item1.replace(qty,'').strip()
            if len(lineitem) == 0:
                qty = 1
                basic = re.search(r'\d+\S+\d+(?!.*\d+\S+\d+)',line_item1).group().strip()  #######match last occurence
                des = line_item1.replace(basic,'').strip()

            print(vendor_name)
            print(address)
            print('Invoice No:',invoice)
            print('Invoice Date:',date)
            print('GST No:',gst)
            print('PAN No:',pan)
            print('Tax',tax)
            print('Total Amount:',total)
            print('Description:',des)
            print('Basic Amount:',basic)
            print('Quantity:',qty)

            # input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
            # # print(input_data)
            # print('\n')
            # vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
            # print(vl)
            # vl1 = list(vl.values())
           
            # list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
            # print("list1" , list1)
            # # create_excel(list1)

            # if vl1.count(True) == 3:
            #     print('Validation Successful')
            #     create_excel(list1)
            #     print('Invoice data extracted to excel')
            # else:
            #     print('Exception Occured')
       

    ##-------------------------Proccess_Intial--------------------------##
    path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
    for data in os.listdir(path):
        data2 = (path+'\\%s')%data
        if data2.endswith('.pdf'):
            pdf_extraction(data2)

Azucane()
