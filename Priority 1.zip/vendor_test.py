from generic_code import header_fields
import pdfplumber
import re
import os
import glob
import openpyxl
from openpyxl import load_workbook
# import validation

def pdf_extraction(data2):
	print(data2)
	print('\n')
	global input_data
	header_values = header_fields(data2)
	# print(header_values)
	invoice = header_values[0]
	date = header_values[1]
	gst = header_values[2]
	pan = header_values[3]
	tax = header_values[4]
	total = header_values[5]
	text = header_values[6]
	# print(text)


	print('Invoice No:',invoice)
	print('Invoice Date:',date)
	print('GST No:',gst)
	print('PAN No:',pan)
	print('Tax',tax)
	print('Total Amount:',total)

	# pan = gst[2:12]

path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
for data in os.listdir(path):
	data2 = (path+'\\%s')%data
	if data2.endswith('.pdf'):
		pdf_extraction(data2)

