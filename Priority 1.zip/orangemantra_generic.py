from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation


def orange_mantra():
	##---------------fixed_functions_For_excel-----------##

	po_number,state_code = create_workbook()
    ##----------------------------------------##
	def pdf_extraction(data2):
		print(data2)
		global input_data
		header_values = header_fields(data2)
		# print(header_values)
		invoice = header_values[0]
		date = header_values[1]
		gst = header_values[2]
		pan = header_values[3]
		tax = header_values[4]
		total = header_values[5]

		text = header_values[6]
		text1 = header_values[8]
		text2 = text1.replace('\n',' ')
		table = header_values[7]
		# print(table)
		# print(text1)
		# print(text)

		try:
			vendor_name = re.search(r'(?i)Orange Mantra',text).group()
		except:
			vendor_name = 'NA'

		try:
			address = re.search(r'.*?\d{6}',text2).group().replace('  ',' ').strip()
		except:
			address = 'NA'

		invoice = re.search(r'(?si)((Invoice|Bill|Inv)(.|\s)(No|Number|Serial No|#)|Invoice#).*?(([A-Z0-9\\\/\-^s]\d\S+){2,16})',text).group()
		invoice = re.search(r'([A-Za-z]+|\d+)[A-Z0-9\\\/\-]+\d+',invoice).group()


		tax = re.search(r'((IGST|CGST|SGST).*?(\d\S\d+\.\d{2}|\d+\S+\d+))',text).group()
		if 'SGST' in tax or 'CGST' in tax:
			tax = float(re.search(r'\%.*',tax).group().replace('%','').replace(' ','').replace(',','')) * 2
		else:
			tax = re.search(r'\%.*',tax).group().replace('%','').replace(' ','')

		total = re.search(r'(?i)RUPEES.*?Total.*',text).group().split('Total')[-1].replace(':','').replace(' ','')

		list4 = []
		for list2 in table:
			for list3 in list2:
				list3 = list(filter(None, list3))
				if list3 != []:
					# print(list3)
					list4.append(list3)
		# print(list4)
		for values in list4:
			for value in values:
				# print(value)
				if 'Item' in value or 'Particulars'.casefold() in value.casefold():
					v1 = list4.index(values)
					print(v1)
				if 'Sub Total' in value:
					v2 = list4.index(values)
					print(v2)
		list4 = list4[v1+1:v2]
		list4 = [line_items for line_items in list4 if len(line_items) != 1]
		for line_items in list4:
			if len(line_items) == 2:
				des = line_items[0]
				qty = 1
				basic = line_items[1]
			elif len(line_items) >3:
				basic = line_items[-2].replace(' ','')
				qty = line_items[-3]
				des = line_items[-4]



			print(vendor_name)
			print(address)
			print('Invoice No:',invoice)
			print('Invoice Date:',date)
			print('GST No:',gst)
			print('PAN No:',pan)
			print('Tax',tax)
			print('Total Amount:',total)
			print('Description:',des)
			print('Basic Amount:',basic)
			print('Quantity:',qty)

			input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
			# print(input_data)
			print('\n')
			vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
			print(vl)
			vl1 = list(vl.values())
	       
			list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
			print("list1" , list1)
			# create_excel(list1)

			if vl1.count(True) == 3:
				print('Validation Successful')
				create_excel(list1)
				print('Invoice data extracted to excel')
			else:
			    print('Exception Occured')


	path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
	for data in os.listdir(path):
		data2 = (path+'\\%s')%data
		if data2.endswith('.pdf'):
			pdf_extraction(data2)
		


orange_mantra()