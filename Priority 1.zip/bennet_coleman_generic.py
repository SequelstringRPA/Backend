from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation



def bennet_coleman():
	##---------------fixed_functions_For_excel-----------##

	po_number,state_code = create_workbook()
    ##----------------------------------------##
	def pdf_extraction(data2):
		print(data2)
		global input_data
		header_values = header_fields(data2)
		#print(header_values)
		invoice = header_values[0]
		date = header_values[1]
		gst = header_values[2]
		pan = header_values[3]
		tax = header_values[4]
		total = header_values[5]

		text = header_values[6]
		# print(text)

		try:
			vendor_name = re.search(r'(?i)Bennet.*?(Limited|Ltd)',text).group()
		except:
			vendor_name = 'NA'

		try:
			address = re.search(r'(?s)Registered office.*?\d{6}',text).group().replace('Registered office','').replace(':','').strip().replace('\n',' ')
		except:
			address = 'NA'

		date = re.search(r'Date.*?(\d+\s+[A-Za-z]+\s+\d+|\d+\/[A-Za-z]+\/\d+|\d+\.[A-Za-z]+\.\d+|\d+\-[A-Za-z]+\-\d+|\d+\s+\d+\s+\d+|\d+\/\d+\/\d+|\d+\.\d+\.\d+|\d+\-\d+\-\d+|\d{1,2}(st|nd|rd|th)\s+[A-Za-z]+\s\d{2,4})',text).group()
		date = re.search(r'\d+\s+[A-Za-z]+\s+\d+|\d+\/[A-Za-z]+\/\d+|\d+\.[A-Za-z]+\.\d+|\d+\-[A-Za-z]+\-\d+|\d+\s+\d+\s+\d+|\d+\/\d+\/\d+|\d+\.\d+\.\d+|\d+\-\d+\-\d+|\d{1,2}(st|nd|rd|th)\s+[A-Za-z]+\s\d{2,4}',date).group()

		total = re.search(r'Net Payable.*?(\d+\,\S+\d+|\d+\S\d+\.\d{2}|\d+\S\d+\.\d{1})',text).group().replace('Net Payable','').replace(' ','').strip()

		line_item_list1 = re.search(r'(?i)(Description|Rate).*?Amount',text).group()
		line_item_list = re.search(f'(?si){line_item_list1}.*?Gross Amount',text).group()
		# print(line_item_list)
		line_items = re.findall(r'\d{3,6}.*\.\d{2}',line_item_list)
		for line_item in line_items:
			print(line_item)
			if re.search(r'[A-Za-z].*[A-Za-z]',line_item):
				des = re.search(r'[A-Za-z].*[A-Za-z]',line_item).group().replace('  ',' ')
			else:
				des = ''
			qty = 1
			basic1 = re.findall(r'\d+\S+\d+',line_item)
			basic = basic1[-1].strip() 




			print(address)
			print('Invoice No:',invoice)
			print('Inoice Date:',date)
			print('GST No:',gst)
			print('PAN No:',pan)
			print('Tax',tax)
			print('Total Amount:',total)
			print('Description:',des)
			print('Basic Amount:',basic)
			print('Quantity:',qty)

			input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
			# print(input_data)
			print('\n')
			vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
			print(vl)
			vl1 = list(vl.values())
	       
			list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
			# print("list1" , list1)
			# create_excel(list1)

			if vl1.count(True) == 3:
				print('Validation Successful')
				create_excel(list1)
				print('Invoice data extracted to excel')
			else:
			    print('Exception Occured')


	path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
	for data in os.listdir(path):
		data2 = (path+'\\%s')%data
		if data2.endswith('.pdf'):
			pdf_extraction(data2)
		


bennet_coleman()