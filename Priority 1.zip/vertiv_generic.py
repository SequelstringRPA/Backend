from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation




def vertiv_energy():
	##---------------fixed_functions_For_excel-----------##
	po_number,state_code = create_workbook()
    ##----------------------------------------##
	def pdf_extraction(data2):
		print(data2)
		global input_data
		header_values = header_fields(data2)
		# print(header_values)
		invoice = header_values[0]
		date = header_values[1]
		gst = header_values[2]
		pan = header_values[3]
		tax = header_values[4]
		total = header_values[5]

		text = header_values[6]
		text1 = header_values[8]
		text2 = text1.replace('\n',' ')
		# print(text2)
		# print(text)

		try:
			vendor_name = re.search(r'(?i)Vertiv.*?(Limited|Ltd)',text).group()
		except:
			vendor_name = 'NA'

		try:
			address = re.search(r'(?si)(Registered|Regd)\s+Office.*?\d{6}',text2).group().replace('\n','').replace('  ',' ').strip()
		except:
			address = 'NA'

		line_item_list = re.search(r'(?si)Description.*?(Net\s+Value|Total\s+Tax)',text).group()
		# print(line_item_list)
		line_items = re.findall(r'\d+.*?\s\d{6}\s.*?\.\d{2}',line_item_list)
		for line_item in line_items:
			# print(line_item)
			des1 = re.search(r'\d+.*?\s\d{6}\s',line_item).group()
			des = des1[2:]
			line_item = line_item.replace(des1,'').split()
			print(line_item)
			qty = line_item[0]
			basic = line_item[1]

			print(vendor_name)
			print(address)
			print('Invoice No:',invoice)
			print('Invoice Date:',date)
			print('GST No:',gst)
			print('PAN No:',pan)
			print('Tax',tax)
			print('Total Amount:',total)
			print('Description:',des)
			print('Basic Amount:',basic)
			print('Quantity:',qty)

			input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
			# print(input_data)
			print('\n')
			vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
			print(vl)
			vl1 = list(vl.values())
	       
			list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
			print("list1" , list1)
			# create_excel(list1)

			if vl1.count(True) == 3:
				print('Validation Successful')
				create_excel(list1)
				print('Invoice data extracted to excel')
			else:
			    print('Exception Occured')


	path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
	for data in os.listdir(path):
		data2 = (path+'\\%s')%data
		if data2.endswith('.pdf'):
			pdf_extraction(data2)
		


vertiv_energy()