from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import validation

def progressive():
	##---------------fixed_functions_For_excel-----------##

	po_number,state_code = create_workbook()
    ##----------------------------------------##
	def pdf_extraction(data2):
		print(data2)
		global input_data
		header_values = header_fields(data2)
		# print(header_values)
		invoice = header_values[0]
		date = header_values[1]
		gst = header_values[2]
		pan = header_values[3]
		tax = header_values[4]
		total = header_values[5]

		text = header_values[6]
		text1 = header_values[8]
		text2 = text1.replace('\n',' ')
		table = header_values[7]
		# print(text)
		# print(text2)
		# print(text1)

		try:
			vendor_name = re.search(r'Progressive.*?(Ltd|Limited)',text).group()
		except:
			vendor_name = 'NA'

		try:
			address = re.search(r'(?s)Registered Office Address.*?\d{6}',text2).group().replace('\n','').replace('Registered Office Address',' ').strip()[2:]
		except:
			address = 'NA'

		if re.search(r'(?s)Invoice\s+Number.*?([A-Za-z]+|\d+)[\\\/\-]+\d+\s',text):
			invoice = re.search(r'(?s)Invoice\s+Number.*?([A-Za-z]+|\d+)[\\\/\-]+\d+\s',text).group().split()[-1]

		try:
			date1 = re.search(r'(?s)\sDATED\s.*?(\d+\s+[A-Za-z]+\s+\d+|\d+\/[A-Za-z]+\/\d+|\d+\.[A-Za-z]+\.\d+|\d+\-[A-Za-z]+\-\d+|\d+\s+\d+\s+\d+|\d+\/\d+\/\d+|\d+\.\d+\.\d+|\d+\-\d+\-\d+|\d{1,2}(st|nd|rd|th)\s+[A-Za-z]+\s\d{2,4})',text).group()
			date = re.search(r'\d+\s+[A-Za-z]+\s+\d+|\d+\/[A-Za-z]+\/\d+|\d+\.[A-Za-z]+\.\d+|\d+\-[A-Za-z]+\-\d+|\d+\s+\d+\s+\d+|\d+\/\d+\/\d+|\d+\.\d+\.\d+|\d+\-\d+\-\d+|\d{1,2}(st|nd|rd|th)\s+[A-Za-z]+\s\d{2,4}',date1).group()
		except:
			date = date

		try:
			try:
				amount_list = re.search(r'Total\s+Amount.*?\.\d{2}.*\.\d{2}',text).group().replace(',','')
			except:
				amount_list = re.search(r'Total\s+Amount.*?\n.*?\.\d{2}.*\.\d{2}',text).group().replace(',','')
		except:
			amount_list = re.search(r'Total\s+\d+.*?\.\d{2}.*\.\d{2}',text).group().replace(',','')
		amount = re.findall(r'\d+\S+',amount_list)
		# print(amount)
		# print(len(amount))
		total = amount[-1]
		del amount[-1]
		del amount[0]
		# print(amount)

		tax = sum(float(amt) for amt in amount)

		line_item_list = re.search(r'(?si)Description.*?((Total\s+Amount)|(CHECKED\s+BY))',text).group()
		# print(line_item_list)
		line_items = re.findall(r'\d+.*?[A-Za-z].*[A-Za-z].*?\d{6}.*?\d+\S+\s.*?\.\d{2}',line_item_list)
		for line_item in line_items:
			des = re.search(r'[A-Za-z].*?[A-Za-z].*?\d{6}',line_item).group()
			line_item = line_item.replace(des,'').split()
			print(line_item)
			basic = line_item[-1]
			qty = line_item[-2]
			if basic == '0.00':
				basic = line_item[1]
				qty = 1

			print(vendor_name)
			print(address)
			print('Invoice No:',invoice)
			print('Invoice Date:',date)
			print('GST No:',gst)
			print('PAN No:',pan)
			print('Tax',tax)
			print('Total Amount:',total)
			print('Description:',des)
			print('Basic Amount:',basic)
			print('Quantity:',qty)

			input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
			# print(input_data)
			print('\n')
			vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
			print(vl)
			vl1 = list(vl.values())
	       
			list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
			print("list1" , list1)
			# create_excel(list1)

			if vl1.count(True) == 3:
				print('Validation Successful')
				create_excel(list1)
				print('Invoice data extracted to excel')
			else:
			    print('Exception Occured')


	path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
	for data in os.listdir(path):
		data2 = (path+'\\%s')%data
		if data2.endswith('.pdf'):
			pdf_extraction(data2)
		


progressive()