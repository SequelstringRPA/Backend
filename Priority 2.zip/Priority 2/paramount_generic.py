from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
import pandas as pd
# import validation



def ab():

    po_number,state_code = create_workbook()

    def pdf_extraction(data2):
        print(data2)
        global input_data
        header_values = header_fields(data2)
        # print(header_values)
        invoice = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]

        text = header_values[6]
        text_t = header_values[7]
        text1 = header_values[8]
        text2 = text1.replace('\n',' ')
        #print(text)


        vendor_name='Paramount Trading Corporation'
        des=[]
        basic=[]
        total=[]
        qty=[]
        tax=[]

        try:
            add=re.search('(?sm)^Authorised.*\d{6}$',text).group()
            address=add[51:]
        except:
            address="Address Is Not Given In PDF"

        date=re.search('Date\s.\d+.\d+.\d+',text).group()
        date=date[6:]

        try:
            total_amount=re.search('Total\s.Round\sup..*|Total\s.round\soff..*',text).group()
            total_amount=total_amount[17:].replace(" ","")
        except:
            total_amount=re.search('Total\s\s.*',text).group()
            total_amount=total_amount[5:].replace(" ","")
           

        x=re.findall('IGST.*',text)
        new=0
        for i in range(len(x)):
            new_x=x[i][11:].replace(",","")
            new_x=new_x.replace(" ","")
            new_x=float(new_x)
            new=new_x+new
            new=round(new,2)
       
        
            


        qty_basic_total=re.findall('\d{1}\s\d{8}.*|\d{1}\s\d{4}.*|\d{2}\s\d{4}.*',text)
        for i in qty_basic_total:
            x=i.split()
            basic.append(x[-2])
            qty.append(x[-4])
            total.append(total_amount)
            tax.append(new)
        
        data=re.search('(?sm)^Sr.*IGST',text).group()
        data=data[70:-4]
        data=data.split('\n')
                   
               
        for i in range(len(qty_basic_total)):
            for j in range(len(data)):
                if data[j]==qty_basic_total[i]:

                    if len(qty_basic_total[i].split())==6:
                        des.append(data[j-1] or data[j+1])

                    elif len(qty_basic_total[i].split())>6:

                        x=qty_basic_total[i].split()
                        x1=x[2:-4]
                        x2=' '.join(x1)
                        des.append(x2)

        
        for i in range(len(qty_basic_total)):
            print(vendor_name)
            print(address)
            print('Invoice No:',invoice)
            print('Invoice Date:',date)
            print('GST No:',gst)
            print('PAN No:',pan)
            print('Tax:',tax[i])
            print('Total Amount:',total[i])
            print('Description:',des[i])
            print('Basic Amount:',basic[i])
            print('Quantity:',qty[i])
            print('\n')
            list1=[[vendor_name,po_number,address,state_code,tax[i],invoice,gst,date,des[i],qty[i],basic[i],total[i],pan]]
            print("list1" , list1)
            create_excel(list1)
            





        


            
       
        
       


        
        #list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
        #print("list1" , list1)
        #create_excel(list1)
            
        
            

        # print(vendor_name)
        # print(address)
        # print('Invoice No:',invoice)
        # print('Invoice Date:',date)
        # print('GST No:',gst)
        # print('PAN No:',pan)
        # print('Tax',tax)
        # print('Total Amount:',total)
        # print('Description:',des)
        # print('Basic Amount:',basic)
        # print('Quantity:',qty)

            # input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
            # print(input_data)
            # print('\n')
            # vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
            # print(vl)
            # vl1 = list(vl.values())
           

            # if vl1.count(True) == 3:
            #   print('Validation Successful')
            #   create_excel(list1)
            #   print('Invoice data extracted to excel')
            # else:
            #     print('Exception Occured')


    path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
    for data in os.listdir(path):
        data2 = (path+'\\%s')%data
        if data2.endswith('.pdf'):
            pdf_extraction(data2)
        


ab()