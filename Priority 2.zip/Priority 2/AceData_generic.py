from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
# import validation



def ab():

    po_number,state_code = create_workbook()

    def pdf_extraction(data2):
        print('***************************************************')
        print(data2)
        global input_data
        header_values = header_fields(data2)
        # print(header_values)
        invoice  = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]

        text = header_values[6]
        text_t = header_values[7]
        text1 = header_values[8]
        text2 = text1.replace('\n',' ')
        #print(text)

     

        vendor_name= re.search(r'ACE.*LIMITED',text2).group()
        
    
        address=re.search(r'ACE.*\n.*?\-\d{6}',text).group().replace('ACE DATA DEVICES PRIVATE LIMITED','').replace('\n','')
        

        date=re.search(r'Inv\.Date.*',text).group().replace('Inv.Date','').replace(' ','')

        tax = re.search(r'otal\sTax.Amount.*',text).group().split(' ')[-1]
                               
        total = re.search(r'Grand.Total.*?\.\d{2}',text).group().split(' ')[-1]

        line_item = re.search(r'DESCRIPTION\sHSN.*\n.*\n.*\n.*\n.*',text).group()
        
        
        a = re.findall('\w+.*\s\s?\d{4}.*?\d+\.\d{2}.*',line_item)
        

        b = line_item.split('\n')[1:]
        
        

        for i in range(len(a)):
            x=a[i].split(' ')
            qty=x[-3]
            basic=x[-2]
            print(vendor_name)
            print(address)
            print('Invoice No:',invoice)
            print('Invoice Date:',date)
            print('GST No:',gst)
            print('PAN No:',pan)
            print('Tax:',tax)
            print('Total Amount:',total)

            
            for j in range(len(b)):
                if a[i]==b[j]:
                    des=b[j-1]
                    print('Description:',des)
                    break
            
            print('Basic Amount:',basic)
            print('Quantity:',qty)
            print('\n')

    
            list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
            print("list1" , list1)
            create_excel(list1) 
            print('\n')
         
                    
        #list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
        #print("list1" , list1)
        #create_excel(list1)
            
        
            

        #print(vendor_name)
        # print(address)
        # print('Invoice No:',invoice)
        # print('Invoice Date:',date)
        # print('GST No:',gst)
        # print('PAN No:',pan)
        # print('Tax',tax)
        # print('Total Amount:',total)
        # print('Description:',des)
        # print('Basic Amount:',basic)
        # print('Quantity:',qty)

            # input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
            # print(input_data)
            # print('\n')
            # vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
            # print(vl)
            # vl1 = list(vl.values())
           

            # if vl1.count(True) == 3:
            #   print('Validation Successful')
            #   create_excel(list1)
            #   print('Invoice data extracted to excel')
            # else:
            #     print('Exception Occured')


    path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
    for data in os.listdir(path):
        data2 = (path+'\\%s')%data
        if data2.endswith('.pdf'):
            pdf_extraction(data2)
        


ab()
