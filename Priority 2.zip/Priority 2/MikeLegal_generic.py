from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
# import validation



def ab():

    po_number,state_code = create_workbook()

    def pdf_extraction(data2):
        print('***************************************************')
        print(data2)
        global input_data
        header_values = header_fields(data2)
        # print(header_values)
        invoice  = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]

        text = header_values[6]
        text_t = header_values[7]
        text1 = header_values[8]
        text2 = text1.replace('\n',' ')
        #print(text)

     

        vendor_name= 'MikeLegal Services Private Limited'

        try:
            address=re.search(r'Registered\s\&.*\n.*\n.*?\d{6}',text).group().replace('\n','').replace('	','').replace('Registered','').replace('-','').replace(':','').replace('&','').replace('Communication','').replace('Address','').strip()
            
        except:
            address=re.search(r'MikeLegal Services.*\n.*\n.*\n.*?\d{6}',text).group().replace('\n','').replace('MikeLegal Services Private Limited','').strip()

        
        try:
            invoice=re.search(r'#\s\s\s\:...........',text).group().split(' ')[-1]
        except:
            invoice=re.search(r'Serial No.*',text).group().split(' ')[-5]

        try:
            date = re.search(r'Date:.*',text).group().split(' ')[-6]

        except:
            pass
                 
            

        try:
            Line_item=re.search(r'Item & Description.*\n.*\n.*',text).group()
        except:
            line_item=re.search(r'Rate  Amount  Rate.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*',text).group()

        try:
            total=re.search(r'Total\sRs.*',text).group().replace('Total Rs.','')
            tax =re.search(r'IGST18.*',text).group().split(' ')[-1]
        except:
            total =re.search(r'\s\sTotal\s\s\d.*',text).group().split('  ')[-1]
            
            
        try:
            a = re.findall('\d{1}\s[a-zA-Z]+.*\d{6}.*',Line_item)
            
        except:
            b = re.findall('.*\s\s18\s\s.*|.*\s\s18\%\s\s.*',line_item)
    

        c = text.split('\n')
            

        try:
            for i in range(len(a)):
                x=a[i].split(' ')
                des = x[1]+' '+x[2]
                qty=x[-5]
                basic=x[-4]
                print(vendor_name)
                print(address)
                print('Invoice No:',invoice)
                print('Invoice Date:',date)
                print('GST No:',gst)
                print('PAN No:',pan)
                print('Tax:',tax)
                print('Total Amount:',total)
                print('Description:',des)
                print('Basic Amount:',basic)
                print('Quantity:',qty)
                print('\n')

                list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
                print("list1" , list1)
                create_excel(list1) 
                print('\n')

        except:
            for i in range(len(b)):
                y=b[i].split(' ')
                for z in range(len(c)):
                    if b[i]==c[z]:
                        des = c[z-1]+' '+y[2]+' '+y[3]+' '+c[z+1]
                        break    
                tax = y[-4]
                qty= ' NOT Given'
                basic=y[-8]
                print(vendor_name)
                print(address)
                print('Invoice No:',invoice)
                print('Invoice Date:',date)
                print('GST No:',gst)
                print('PAN No:',pan)
                print('Tax:',tax)
                print('Total Amount:',total)
                des = des.strip()
                print('Description:',des)
                print('Basic Amount:',basic)
                print('Quantity:',qty)
                print('\n')

    
                list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
                print("list1" , list1)
                create_excel(list1) 
                print('\n')
         
####                    
####        #list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
####        #print("list1" , list1)
####        #create_excel(list1)
##            
        
            

        #print(vendor_name)
        # print(address)
        # print('Invoice No:',invoice)
        # print('Invoice Date:',date)
        # print('GST No:',gst)
        # print('PAN No:',pan)
        # print('Tax',tax)
        # print('Total Amount:',total)
        # print('Description:',des)
        # print('Basic Amount:',basic)
        # print('Quantity:',qty)

            # input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
            # print(input_data)
            # print('\n')
            # vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
            # print(vl)
            # vl1 = list(vl.values())
           

            # if vl1.count(True) == 3:
            #   print('Validation Successful')
            #   create_excel(list1)
            #   print('Invoice data extracted to excel')
            # else:
            #     print('Exception Occured')


    path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
    for data in os.listdir(path):
        data2 = (path+'\\%s')%data
        if data2.endswith('.pdf'):
            pdf_extraction(data2)
        


ab()
