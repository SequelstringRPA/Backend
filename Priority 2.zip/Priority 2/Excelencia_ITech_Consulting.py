from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
# import validation



def ab():

    po_number,state_code = create_workbook()

    def pdf_extraction(data2):
        print(data2)
        global input_data
        header_values = header_fields(data2)
        # print(header_values)
        invoice = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]

        text = header_values[6]
        text_t = header_values[7]
        text1 = header_values[8]
        text2 = text1.replace('\n',' ')
        # print(text)

        vendor_name='Excelencia ITech Consulting Pvt Ltd'
        total=[]
        des=[]
        basic=[]
        qty=[]
        tax=[]

        address=re.search('Exc.*\n.*\n.*\d{6}',text).group().replace('\n',' ')[37:]
        address=address.replace(re.search('DATE.*\d{4}',text).group(),'')

        date=re.search('DATE.*\d{4}',text).group()[6:]

        data=re.search('(?sm)Serial.*THANK\sYOU',text).group()

        total=re.search('Round.*',data).group()[16:]
        
        tax=re.search('Add.*',data).group()[31:]
        tax=tax.replace(' ','')

        line_item=re.findall('(?m)^\d.*',data)
        for i in line_item:
            if len(i.split())==6:
                qty.append(i.split()[2])
                basic.append(i.split()[3])

            elif len(i.split())>6:
                try:
                    if int(i.split()[2])==True:
                        qty.append(i.split()[2])
                except:
                     qty.append('N/A')


                try:
                    b=i.split()[3:5]
                    b1=float(''.join(b).replace(',',''))
                    if type(b1)==float:
                        basic.append(b1)
                    else:
                        basic.append('N/A')
                except:
                    basic.append('N/A')


            else :
                qty.append('N/A')
                basic.append('N/A')


        new_data=data.split('\n')
        for i in range(len(line_item)):
            for j in range(len(new_data)):
                if line_item[i]==new_data[j]:
                    des.append(new_data[j-1])



        for i in range(len(line_item)):
	        print(vendor_name)
	        print(address)
	        print('Invoice No:',invoice)
	        print('Invoice Date:',date)
	        print('GST No:',gst)
	        print('PAN No:',pan)
	        print('Tax',tax)
	        print('Total Amount:',total)
	        print('Description:',des[i])
	        print('Basic Amount:',basic[i])
	        print('Quantity:',qty[i])

	        list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des[i],qty[i],basic[i],total,pan]]
	        print("list1" , list1)
	        create_excel(list1)

        
 


        
        
        #list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
        #print("list1" , list1)
        #create_excel(list1)
            
        
            

        # print(vendor_name)
        # print(address)
        # print('Invoice No:',invoice)
        # print('Invoice Date:',date)
        # print('GST No:',gst)
        # print('PAN No:',pan)
        # print('Tax',tax)
        # print('Total Amount:',total)
        # print('Description:',des)
        # print('Basic Amount:',basic)
        # print('Quantity:',qty)

            # input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
            # print(input_data)
            # print('\n')
            # vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
            # print(vl)
            # vl1 = list(vl.values())
           

            # if vl1.count(True) == 3:
            #   print('Validation Successful')
            #   create_excel(list1)
            #   print('Invoice data extracted to excel')
            # else:
            #     print('Exception Occured')


    path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')

    for data in os.listdir(path):

        data2 = (path+'\\%s')%data

        if data2.endswith('.pdf'):

            pdf_extraction(data2)
        


ab()