from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
# import validation



def ab():

    po_number,state_code = create_workbook()

    def pdf_extraction(data2):
        print(data2)
        global input_data
        header_values = header_fields(data2)
        # print(header_values)
        invoice  = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]

        text = header_values[6]
        text_t = header_values[7]
        text1 = header_values[8]
        text2 = text1.replace('\n',' ')
        #print(text)

        



        try:
            vendor_name= re.search(r'Original\s\w{3}\s\w{9}.*\n.*?Limited',text).group().replace('Original for recipient','').replace('\n','')
            
        except:
            vendor_name= re.search(r'Original\s\w{3}\s\w{9}\.*\n.*\n.*\n.*?Limited',text).group().replace('Original For Recipient','').replace('\n','').replace('InvoiceRegistered Office:','')
            
        

        try:
            address= re.search(r'Original\s\w{3}\s\w{9}.*\n.*\n.*\n.*\n.*?India',text).group().replace('Original for recipient','').replace('\n','').replace('ETAS Automotive India Private Limited','').replace(' ','')
            
        except:
            address= re.search(r'Original\s\w{3}\s\w{9}.*\n.*\n.*\n.*\n.*\n.*\n.*?INDIA',text).group().replace('Original For Recipient','').replace('\n','').replace('InvoiceRegistered Office:','').replace('ETAS Automotive India Private Limited','')
        
            

        try:
           line_item = re.search(r'Sl No.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n',text).group()
           d = re.findall('\d{2}\s\w\d{2}.*',line_item)
           for i in range(len(d)):
               x=d[i].split()
               date= re.search(r'Date of Tax Invoice.*',text).group()[20:]
               tax =re.search(r'Tax Amount\s.*',text).group()[11:]
               total = re.search(r'Total Value\s.*',text).group()[12:]            
               #print(x)
               des = x[1]
               basic = x[-1]
               qty = x[2]
               print(vendor_name)
               print(address)
               print('Invoice No:',invoice)
               print('Invoice Date:',date)
               print('GST No:',gst)
               print('PAN No:',pan)
               print('Tax:',tax)
               print('Total Amount:',total)
               print('Description:',des)
               print('Basic Amount:',basic)
               print('Quantity:',qty)
               print('\n')
               
               list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
               print("list1" , list1)
               create_excel(list1)
               print('\n')

               
        except:
            line_item = re.search(r'Pos\..*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*?country',text).group()
            d = re.findall('\d{4}\s\w\-\d{2}\w\-.*',line_item)
            for i in range(len(d)):
                x=d[i].split()
                #print(x)
                dat=re.search(r'Invoice Date.*?Responsible Contact',text2).group().split()
                lists=re.search(r'Total Net Value Tax.*?INR',text2).group().split()
                gst=re.search(r'GST\-No\..*?Bill\-To',text2).group()[7:-7]
                date=dat[-3]
                tax = lists[-3]
                total = lists[-2]
                des = x[2:8]
                des=' '.join(des)
                basic = x[-5]
                qty = x[-4]
                print(vendor_name)
                print(address)
                print('Invoice No:',invoice)
                print('Invoice Date:',date)
                print('GST No:',gst)
                print('PAN No:',pan)
                print('Tax:',tax)
                print('Total Amount:',total)
                print('Description:',des)
                print('Basic Amount:',basic)
                print('Quantity:',qty)
                print('\n')
                


                
                list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
                print("list1" , list1)
                create_excel(list1) 
                print('\n')
    
        
        #list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
        #print("list1" , list1)
        #create_excel(list1)
            
        
            

        #print(vendor_name)
        # print(address)
        # print('Invoice No:',invoice)
        # print('Invoice Date:',date)
        # print('GST No:',gst)
        # print('PAN No:',pan)
        # print('Tax',tax)
        # print('Total Amount:',total)
        # print('Description:',des)
        # print('Basic Amount:',basic)
        # print('Quantity:',qty)

            # input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
            # print(input_data)
            # print('\n')
            # vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
            # print(vl)
            # vl1 = list(vl.values())
           

            # if vl1.count(True) == 3:
            #   print('Validation Successful')
            #   create_excel(list1)
            #   print('Invoice data extracted to excel')
            # else:
            #     print('Exception Occured')


    path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')
    for data in os.listdir(path):
        data2 = (path+'\\%s')%data
        if data2.endswith('.pdf'):
            pdf_extraction(data2)
        


ab()
