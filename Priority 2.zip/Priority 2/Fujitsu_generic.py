from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
# import validation



def ab():

    po_number,state_code = create_workbook()

    def pdf_extraction(data2):
        print(data2)
        global input_data
        header_values = header_fields(data2)
        # print(header_values)
        invoice = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]

        text = header_values[6]
        text_t = header_values[7]
        text1 = header_values[8]
        text2 = text1.replace('\n',' ')
        #print(text)

        vendor_name='FUJITSU INDIA PRIVATE LIMITED'
        total=[]
        des=[]
        basic=[]
        qty=[]
        tax=[]

        address=re.search('3rd.*Haryana\s\d{6}',text2).group()

        try:
        	total_amount=re.search('Total\sValue\s..*',text).group()
        	total=total_amount[14:]
        	
        except:
        	total_amount=re.search('Invoice\sTotal\s..*',text).group()
        	total=total_amount[16:]
        	

        tax_amount=re.search('Total\sTax\s..*',text).group()
        tax=tax_amount[12:]

        data=re.findall('\d\.\s\w+.*',text)
       

        for i in range(len(data)):
        	x=data[i].split()
        	basic.append(x[-6])
        	qty.append(x[-7])
        	des.append(' '.join(x[1:-8]))


        for i in range(len(data)):
	        print(vendor_name)
	        print(address)
	        print('Invoice No:',invoice)
	        print('Invoice Date:',date)
	        print('GST No:',gst)
	        print('PAN No:',pan)
	        print('Tax',tax)
	        print('Total Amount:',total)
	        print('Description:',des[i])
	        print('Basic Amount:',basic[i])
	        print('Quantity:',qty[i])
	        list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des[i],qty[i],basic[i],total,pan]]
	        print("list1" , list1)
	        create_excel(list1)

        
 


        
        
        #list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
        #print("list1" , list1)
        #create_excel(list1)
            
        
            

        # print(vendor_name)
        # print(address)
        # print('Invoice No:',invoice)
        # print('Invoice Date:',date)
        # print('GST No:',gst)
        # print('PAN No:',pan)
        # print('Tax',tax)
        # print('Total Amount:',total)
        # print('Description:',des)
        # print('Basic Amount:',basic)
        # print('Quantity:',qty)

            # input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
            # print(input_data)
            # print('\n')
            # vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
            # print(vl)
            # vl1 = list(vl.values())
           

            # if vl1.count(True) == 3:
            #   print('Validation Successful')
            #   create_excel(list1)
            #   print('Invoice data extracted to excel')
            # else:
            #     print('Exception Occured')


    path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')

    for data in os.listdir(path):

        data2 = (path+'\\%s')%data

        if data2.endswith('.pdf'):

            pdf_extraction(data2)
        


ab()