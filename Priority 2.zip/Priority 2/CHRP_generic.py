from generic_code import header_fields
import re
import os
from excel_creation import create_workbook,create_excel
# import validation



def ab():

    po_number,state_code = create_workbook()

    def pdf_extraction(data2):
        print(data2)
        global input_data
        header_values = header_fields(data2)
        # print(header_values)
        invoice = header_values[0]
        date = header_values[1]
        gst = header_values[2]
        pan = header_values[3]
        tax = header_values[4]
        total = header_values[5]

        text = header_values[6]
        text_t = header_values[7]
        text1 = header_values[8]
        text2 = text1.replace('\n',' ')
        #print(text)

        vendor_name='CHRP-INDIA Pvt. Ltd.'
        des=[]
        qty=[]
        tax=[]
        total=[]
        basic=[]

        add=re.search('(?sm)^Concoct.*Telangana\,\sIndia\.',text).group()
        address=add[55:].replace('\n','')

        date=re.search('Date.\s\d+\w+\s\w+\s\d+',text).group()
        date=date[6:]

    
        	

        try:
            data=re.search('(?sm)Particulars.*Payable\sin\sfavor\sof\,',text).group()
            new_data=re.findall('\d+\.\s.*|\d{7}\s\s\d{6}.*|\d{1}\s\s\d{8}.*|\d{1}\s\s\d{6}\s\s\w+.*',data)
           
           
            try:
                total_amount=re.search('Total\sInc.*',data).group()
                total_amount=total_amount[25:]
                total_amount=total_amount.split()
                total_amount=total_amount[-1]
            except:
                total_amount=re.search('(?m)^(\d{2}\s\w{5}.*)',data).group()
                total_amount=total_amount.split()
                total_amount=total_amount[-1]


            total_tax=0

            for i in range(len(new_data)):

                x=new_data[i].split()
                
                tax_for_single_item=float(x[-2])
                tax_for_all_item=float(x[-5])*tax_for_single_item
                total_tax=total_tax+tax_for_all_item


            for i in range(len(new_data)):
                x=new_data[i].split()
                basic.append(x[-3])
                total.append(total_amount)
                tax.append(total_tax)
                qty.append(x[-5])
                des.append(' '.join(x[2:-5]))
            
            for i in range(len(new_data)):

                print(vendor_name)
                print(address)
                print('Invoice No:',invoice)
                print('Invoice Date:',date)
                print('GST No:',gst)
                print('PAN No:',pan)
                print('Tax',tax[i])
                print('Total Amount:',total[i])
                print('Description:',des[i])
                print('Basic Amount:',basic[i])
                print('Quantity:',qty[i])
                print('\n')
                list1=[[vendor_name,po_number,address,state_code,tax[i],invoice,gst,date,des[i],qty[i],basic[i],total[i],pan]]
                print("list1" , list1)
                create_excel(list1)



        except :
            data=re.search('(?sm)^Sr.*Amount',text).group()
            new_data=re.findall('\d+\.\s.*',data)

            total_tax1=re.search('Add\:\sIGST\s\(\@18\.00\s\%\)\s\s\d+.\d+',text).group()
            total_tax1=total_tax1[22:]

            total_amount1=re.search('Total\s\s\d+.\d+',text).group()
            total_amount1=total_amount1[7:]


            for i in range(len(new_data)):
                x=new_data[i].split()
                basic.append(x[-1])
                qty.append(x[-3])
                des.append(' '.join(x[1:-3]))
                tax.append(total_tax1)
                total.append(total_amount1)

            for i in range(len(new_data)):

                print(vendor_name)
                print(address)
                print('Invoice No:',invoice)
                print('Invoice Date:',date)
                print('GST No:',gst)
                print('PAN No:',pan)
                print('Tax',tax[i])
                print('Total Amount:',total[i])
                print('Description:',des[i])
                print('Basic Amount:',basic[i])
                print('Quantity:',qty[i])
                print('\n')
                list1=[[vendor_name,po_number,address,state_code,tax[i],invoice,gst,date,des[i],qty[i],basic[i],total[i],pan]]
                print("list1" , list1)
                create_excel(list1)


        
        #list1=[[vendor_name,po_number,address,state_code,tax,invoice,gst,date,des,qty,basic,total,pan]]
        #print("list1" , list1)
        #create_excel(list1)
            
        
            

        # print(vendor_name)
        # print(address)
        # print('Invoice No:',invoice)
        # print('Invoice Date:',date)
        # print('GST No:',gst)
        # print('PAN No:',pan)
        # print('Tax',tax)
        # print('Total Amount:',total)
        # print('Description:',des)
        # print('Basic Amount:',basic)
        # print('Quantity:',qty)

            # input_data = [vendor_name,address,tax,invoice,gst,date,des,qty,basic,total,pan]
            # print(input_data)
            # print('\n')
            # vl = validation.valid_data(input_data)# function call to check extracted data is valid or not
            # print(vl)
            # vl1 = list(vl.values())
           

            # if vl1.count(True) == 3:
            #   print('Validation Successful')
            #   create_excel(list1)
            #   print('Invoice data extracted to excel')
            # else:
            #     print('Exception Occured')


    path=os.path.join(os.getcwd(),'Inprocess').replace('\Codes','')

    for data in os.listdir(path):

        data2 = (path+'\\%s')%data

        if data2.endswith('.pdf'):

            pdf_extraction(data2)
        


ab()